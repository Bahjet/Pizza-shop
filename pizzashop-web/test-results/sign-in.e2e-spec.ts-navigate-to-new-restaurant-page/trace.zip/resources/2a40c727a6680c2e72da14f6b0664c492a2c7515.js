import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=12cb1194";
export const signInMock = http.post(
  "/authenticate",
  async ({ request }) => {
    const { email } = await request.json();
    if (email === "bahjetmk@gmail.com") {
      return new HttpResponse(null, {
        status: 200,
        headers: {
          "Set-Cookie": "auth=sample-jwt"
        }
      });
    }
    return new HttpResponse(null, { status: 401 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZ24taW4tbW9jay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBodHRwLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdtc3cnXHJcblxyXG5pbXBvcnQgeyBTaWduSW5Cb2R5IH0gZnJvbSAnLi4vc2lnbi1pbidcclxuXHJcbmV4cG9ydCBjb25zdCBzaWduSW5Nb2NrID0gaHR0cC5wb3N0PG5ldmVyLCBTaWduSW5Cb2R5PihcclxuICAnL2F1dGhlbnRpY2F0ZScsXHJcbiAgYXN5bmMgKHsgcmVxdWVzdCB9KSA9PiB7XHJcbiAgICBjb25zdCB7IGVtYWlsIH0gPSBhd2FpdCByZXF1ZXN0Lmpzb24oKVxyXG5cclxuICAgIGlmIChlbWFpbCA9PT0gJ2JhaGpldG1rQGdtYWlsLmNvbScpIHtcclxuICAgICAgcmV0dXJuIG5ldyBIdHRwUmVzcG9uc2UobnVsbCwge1xyXG4gICAgICAgIHN0YXR1czogMjAwLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdTZXQtQ29va2llJzogJ2F1dGg9c2FtcGxlLWp3dCcsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gbmV3IEh0dHBSZXNwb25zZShudWxsLCB7IHN0YXR1czogNDAxIH0pXHJcbiAgfSxcclxuKVxyXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsTUFBTSxvQkFBb0I7QUFJNUIsYUFBTSxhQUFhLEtBQUs7QUFBQSxFQUM3QjtBQUFBLEVBQ0EsT0FBTyxFQUFFLFFBQVEsTUFBTTtBQUNyQixVQUFNLEVBQUUsTUFBTSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBRXJDLFFBQUksVUFBVSxzQkFBc0I7QUFDbEMsYUFBTyxJQUFJLGFBQWEsTUFBTTtBQUFBLFFBQzVCLFFBQVE7QUFBQSxRQUNSLFNBQVM7QUFBQSxVQUNQLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFFQSxXQUFPLElBQUksYUFBYSxNQUFNLEVBQUUsUUFBUSxJQUFJLENBQUM7QUFBQSxFQUMvQztBQUNGOyIsIm5hbWVzIjpbXX0=