import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/account-menu.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { Building, ChevronDown, LogOut } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { getManagedRestaurant } from "/src/api/get-managed-restaurant.ts?t=1713839672183";
import { getProfile } from "/src/api/get-profile.ts?t=1713816428310";
import { signOut } from "/src/api/sign-out.ts";
import { StoreProfileDialog } from "/src/components/store-profile-dialog.tsx?t=1713839672183";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
export function AccountMenu() {
  _s();
  const navigate = useNavigate();
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ["profile"],
    queryFn: getProfile,
    staleTime: Infinity
  });
  const { data: managedRestaurant, isLoading: isLoadingManagedRestaurant } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getManagedRestaurant,
    staleTime: Infinity
  });
  const { mutateAsync: signOutFn, isPending: isSigningOut } = useMutation({
    mutationFn: signOut,
    onSuccess: () => {
      navigate("/sign-in", { replace: true });
    }
  });
  return /* @__PURE__ */ jsxDEV(Dialog, { children: [
    /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          className: "flex select-none items-center gap-2",
          children: [
            isLoadingManagedRestaurant ? /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-40" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
              lineNumber: 54,
              columnNumber: 13
            }, this) : managedRestaurant?.name,
            /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h4 w-4" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
              lineNumber: 58,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 49,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", className: "w-56", children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex flex-col", children: isLoadingProfile ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-32" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 65,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-3 w-24" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 66,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 64,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("span", { children: profile?.name }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 70,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-muted-foregorund text-xs font-normal", children: profile?.email }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 71,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 69,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: [
          /* @__PURE__ */ jsxDEV(Building, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 81,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Perfil da loja" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 82,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 80,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
          lineNumber: 79,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          DropdownMenuItem,
          {
            asChild: true,
            className: "text-rose-500 dark:text-rose-400",
            disabled: isSigningOut,
            children: /* @__PURE__ */ jsxDEV("button", { className: "w-full", onClick: () => signOutFn(), children: [
              /* @__PURE__ */ jsxDEV(LogOut, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
                lineNumber: 92,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Sair" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
                lineNumber: 93,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
              lineNumber: 91,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
            lineNumber: 86,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(StoreProfileDialog, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
      lineNumber: 98,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(AccountMenu, "Ml3uKNdSghuCAXtIWq0kOtOG4y0=", false, function() {
  return [useNavigate, useQuery, useQuery, useMutation];
});
_c = AccountMenu;
var _c;
$RefreshReg$(_c, "AccountMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/account-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURjLFNBZUEsVUFmQTsyQkFyRGQ7QUFBb0IsTUFBRUEsY0FBZ0IsNkJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzdELFNBQVNDLFVBQVVDLGFBQWFDLGNBQWM7QUFDOUMsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsZUFBZTtBQUV4QixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZ0JBQWdCO0FBRWxCLGdCQUFTQyxjQUFjO0FBQUFDLEtBQUE7QUFDNUIsUUFBTUMsV0FBV2pCLFlBQVk7QUFFN0IsUUFBTSxFQUFFa0IsTUFBTUMsU0FBU0MsV0FBV0MsaUJBQWlCLElBQUl6QixTQUFTO0FBQUEsSUFDOUQwQixVQUFVLENBQUMsU0FBUztBQUFBLElBQ3BCQyxTQUFTckI7QUFBQUEsSUFDVHNCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU0sRUFBRVAsTUFBTVEsbUJBQW1CTixXQUFXTywyQkFBMkIsSUFDckUvQixTQUFTO0FBQUEsSUFDUDBCLFVBQVUsQ0FBQyxvQkFBb0I7QUFBQSxJQUMvQkMsU0FBU3RCO0FBQUFBLElBQ1R1QixXQUFXQztBQUFBQSxFQUNiLENBQUM7QUFFSCxRQUFNLEVBQUVHLGFBQWFDLFdBQVdDLFdBQVdDLGFBQWEsSUFBSUMsWUFBWTtBQUFBLElBQ3RFQyxZQUFZOUI7QUFBQUEsSUFDWitCLFdBQVdBLE1BQU07QUFDZmpCLGVBQVMsWUFBWSxFQUFFa0IsU0FBUyxLQUFLLENBQUM7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUVELFNBQ0UsdUJBQUMsVUFDQztBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsdUJBQW9CLFNBQU8sTUFDMUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVE7QUFBQSxVQUNSLFdBQVU7QUFBQSxVQUVUUjtBQUFBQSx5Q0FDQyx1QkFBQyxZQUFTLFdBQVUsY0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEIsSUFFOUJELG1CQUFtQlU7QUFBQUEsWUFFckIsdUJBQUMsZUFBWSxXQUFVLFlBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUE7QUFBQTtBQUFBLFFBVGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyx1QkFBb0IsT0FBTSxPQUFNLFdBQVUsUUFDekM7QUFBQSwrQkFBQyxxQkFBa0IsV0FBVSxpQkFDMUJmLDZCQUNDLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsYUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxVQUFNRixtQkFBU2lCLFFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFDckIsdUJBQUMsVUFBSyxXQUFVLDZDQUNiakIsbUJBQVNrQixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLFFBRXRCLHVCQUFDLGlCQUFjLFNBQU8sTUFDcEIsaUNBQUMsb0JBQ0M7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsVUFDbEMsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLGFBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixVQUFVTjtBQUFBQSxZQUVWLGlDQUFDLFlBQU8sV0FBVSxVQUFTLFNBQVMsTUFBTUYsVUFBVSxHQUNsRDtBQUFBLHFDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQVU7QUFBQSxpQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBLFNBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrREE7QUFBQSxJQUNBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUI7QUFBQSxPQXBEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFEQTtBQUVKO0FBQUNiLEdBL0VlRCxhQUFXO0FBQUEsVUFDUmYsYUFFc0NKLFVBT3JEQSxVQU0wRG9DLFdBQVc7QUFBQTtBQUFBTSxLQWhCekR2QjtBQUFXLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUXVlcnkiLCJCdWlsZGluZyIsIkNoZXZyb25Eb3duIiwiTG9nT3V0IiwidXNlTmF2aWdhdGUiLCJnZXRNYW5hZ2VkUmVzdGF1cmFudCIsImdldFByb2ZpbGUiLCJzaWduT3V0IiwiU3RvcmVQcm9maWxlRGlhbG9nIiwiQnV0dG9uIiwiRGlhbG9nIiwiRGlhbG9nVHJpZ2dlciIsIkRyb3Bkb3duTWVudSIsIkRyb3Bkb3duTWVudUNvbnRlbnQiLCJEcm9wZG93bk1lbnVJdGVtIiwiRHJvcGRvd25NZW51TGFiZWwiLCJEcm9wZG93bk1lbnVTZXBhcmF0b3IiLCJEcm9wZG93bk1lbnVUcmlnZ2VyIiwiU2tlbGV0b24iLCJBY2NvdW50TWVudSIsIl9zIiwibmF2aWdhdGUiLCJkYXRhIiwicHJvZmlsZSIsImlzTG9hZGluZyIsImlzTG9hZGluZ1Byb2ZpbGUiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJzdGFsZVRpbWUiLCJJbmZpbml0eSIsIm1hbmFnZWRSZXN0YXVyYW50IiwiaXNMb2FkaW5nTWFuYWdlZFJlc3RhdXJhbnQiLCJtdXRhdGVBc3luYyIsInNpZ25PdXRGbiIsImlzUGVuZGluZyIsImlzU2lnbmluZ091dCIsInVzZU11dGF0aW9uIiwibXV0YXRpb25GbiIsIm9uU3VjY2VzcyIsInJlcGxhY2UiLCJuYW1lIiwiZW1haWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImFjY291bnQtbWVudS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBCdWlsZGluZywgQ2hldnJvbkRvd24sIExvZ091dCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5cclxuaW1wb3J0IHsgZ2V0TWFuYWdlZFJlc3RhdXJhbnQgfSBmcm9tICdAL2FwaS9nZXQtbWFuYWdlZC1yZXN0YXVyYW50J1xyXG5pbXBvcnQgeyBnZXRQcm9maWxlIH0gZnJvbSAnQC9hcGkvZ2V0LXByb2ZpbGUnXHJcbmltcG9ydCB7IHNpZ25PdXQgfSBmcm9tICdAL2FwaS9zaWduLW91dCdcclxuXHJcbmltcG9ydCB7IFN0b3JlUHJvZmlsZURpYWxvZyB9IGZyb20gJy4vc3RvcmUtcHJvZmlsZS1kaWFsb2cnXHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ1RyaWdnZXIgfSBmcm9tICcuL3VpL2RpYWxvZydcclxuaW1wb3J0IHtcclxuICBEcm9wZG93bk1lbnUsXHJcbiAgRHJvcGRvd25NZW51Q29udGVudCxcclxuICBEcm9wZG93bk1lbnVJdGVtLFxyXG4gIERyb3Bkb3duTWVudUxhYmVsLFxyXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcclxuICBEcm9wZG93bk1lbnVUcmlnZ2VyLFxyXG59IGZyb20gJy4vdWkvZHJvcGRvd24tbWVudSdcclxuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICcuL3VpL3NrZWxldG9uJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFjY291bnRNZW51KCkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG5cclxuICBjb25zdCB7IGRhdGE6IHByb2ZpbGUsIGlzTG9hZGluZzogaXNMb2FkaW5nUHJvZmlsZSB9ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFsncHJvZmlsZSddLFxyXG4gICAgcXVlcnlGbjogZ2V0UHJvZmlsZSxcclxuICAgIHN0YWxlVGltZTogSW5maW5pdHksXHJcbiAgfSlcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBtYW5hZ2VkUmVzdGF1cmFudCwgaXNMb2FkaW5nOiBpc0xvYWRpbmdNYW5hZ2VkUmVzdGF1cmFudCB9ID1cclxuICAgIHVzZVF1ZXJ5KHtcclxuICAgICAgcXVlcnlLZXk6IFsnbWFuYWdlZC1yZXN0YXVyYW50J10sXHJcbiAgICAgIHF1ZXJ5Rm46IGdldE1hbmFnZWRSZXN0YXVyYW50LFxyXG4gICAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxyXG4gICAgfSlcclxuXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogc2lnbk91dEZuLCBpc1BlbmRpbmc6IGlzU2lnbmluZ091dCB9ID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25Gbjogc2lnbk91dCxcclxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xyXG4gICAgICBuYXZpZ2F0ZSgnL3NpZ24taW4nLCB7IHJlcGxhY2U6IHRydWUgfSlcclxuICAgIH0sXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxEaWFsb2c+XHJcbiAgICAgIDxEcm9wZG93bk1lbnU+XHJcbiAgICAgICAgPERyb3Bkb3duTWVudVRyaWdnZXIgYXNDaGlsZD5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHNlbGVjdC1ub25lIGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtpc0xvYWRpbmdNYW5hZ2VkUmVzdGF1cmFudCA/IChcclxuICAgICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctNDBcIiAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIG1hbmFnZWRSZXN0YXVyYW50Py5uYW1lXHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJoNCB3LTRcIiAvPlxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxyXG4gICAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy01NlwiPlxyXG4gICAgICAgICAgPERyb3Bkb3duTWVudUxhYmVsIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZ1Byb2ZpbGUgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTMyXCIgLz5cclxuICAgICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTMgdy0yNFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxzcGFuPntwcm9maWxlPy5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdvcnVuZCB0ZXh0LXhzIGZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9maWxlPy5lbWFpbH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvRHJvcGRvd25NZW51TGFiZWw+XHJcbiAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIC8+XHJcblxyXG4gICAgICAgICAgPERpYWxvZ1RyaWdnZXIgYXNDaGlsZD5cclxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+UGVyZmlsIGRhIGxvamE8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cclxuICAgICAgICAgIDwvRGlhbG9nVHJpZ2dlcj5cclxuXHJcbiAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxyXG4gICAgICAgICAgICBhc0NoaWxkXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2lnbmluZ091dH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ3LWZ1bGxcIiBvbkNsaWNrPXsoKSA9PiBzaWduT3V0Rm4oKX0+XHJcbiAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlNhaXI8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxyXG4gICAgICAgIDwvRHJvcGRvd25NZW51Q29udGVudD5cclxuICAgICAgPC9Ecm9wZG93bk1lbnU+XHJcbiAgICAgIDxTdG9yZVByb2ZpbGVEaWFsb2cgLz5cclxuICAgIDwvRGlhbG9nPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvY29tcG9uZW50cy9hY2NvdW50LW1lbnUudHN4In0=