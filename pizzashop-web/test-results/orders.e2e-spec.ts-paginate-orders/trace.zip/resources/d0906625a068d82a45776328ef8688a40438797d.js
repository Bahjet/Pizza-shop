import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-row.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=12cb1194";
import { ptBR } from "/node_modules/.vite/deps/date-fns_locale.js?v=12cb1194";
import { ArrowRight, Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=12cb1194"; const useState = __vite__cjsImport7_react["useState"];
import { approveOrder } from "/src/api/approve-order.ts";
import { cancelOrder } from "/src/api/cancel-order.ts";
import { deliverOrder } from "/src/api/deliver-order.ts";
import { dispatchOrder } from "/src/api/dispatch-order.ts?t=1713894108050";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
import { OrderStatus } from "/src/components/order-status.tsx";
import { OrderDetails } from "/src/pages/app/orders/order-details.tsx";
export function OrderTableRow({ order }) {
  _s();
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const queryClient = useQueryClient();
  function updateOrderStatusOnCache(orderId, status) {
    const ordersListCache = queryClient.getQueriesData({
      queryKey: ["orders"]
    });
    ordersListCache.forEach(([cacheKey, cacheData]) => {
      if (!cacheData) {
        return;
      }
      queryClient.setQueryData(cacheKey, {
        ...cacheData,
        orders: cacheData.orders.map((order2) => {
          if (order2.orderId === orderId) {
            return { ...order2, status };
          }
          return order2;
        })
      });
    });
  }
  const { mutateAsync: cancelOrderFn, isPending: isCancelingOrder } = useMutation({
    mutationFn: cancelOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "canceled");
    }
  });
  const { mutateAsync: approveOrderFn, isPending: isApprovingOrder } = useMutation({
    mutationFn: approveOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "processing");
    }
  });
  const { mutateAsync: dispatchOrderFn, isPending: isDispatchingOrder } = useMutation({
    mutationFn: dispatchOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "delivering");
    }
  });
  const { mutateAsync: deliverOrderFn, isPending: isDeliveringOrder } = useMutation({
    mutationFn: deliverOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnCache(orderId, "delivered");
    }
  });
  return /* @__PURE__ */ jsxDEV(TableRow, { children: [
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Dialog, { open: isDetailsOpen, onOpenChange: setIsDetailsOpen, children: [
      /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "xs", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 94,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 95,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 93,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 92,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(OrderDetails, { open: isDetailsOpen, orderId: order.orderId }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 98,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 91,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-mono text-xs font-medium", children: order.orderId }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: formatDistanceToNow(order.createdAt, {
      locale: ptBR,
      addSuffix: true
    }) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(OrderStatus, { status: order.status }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 111,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium", children: order.customerName }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium", children: (order.total / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    }) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: [
      order.status === "pending" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => approveOrderFn({ orderId: order.orderId }),
          disabled: isApprovingOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 128,
              columnNumber: 13
            }, this),
            "Aprovar"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 122,
          columnNumber: 9
        },
        this
      ),
      order.status === "processing" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => dispatchOrderFn({ orderId: order.orderId }),
          disabled: isDispatchingOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 140,
              columnNumber: 13
            }, this),
            "Em entrega"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 134,
          columnNumber: 9
        },
        this
      ),
      order.status === "delivering" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => deliverOrderFn({ orderId: order.orderId }),
          disabled: isDeliveringOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 151,
              columnNumber: 13
            }, this),
            "Entregue"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 145,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        disabled: !["pending", "processing"].includes(order.status) || isCancelingOrder,
        onClick: () => cancelOrderFn({ orderId: order.orderId }),
        variant: "ghost",
        size: "xs",
        children: [
          /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-3 w-3" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
            lineNumber: 166,
            columnNumber: 11
          }, this),
          "Cancelar"
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 157,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx",
    lineNumber: 89,
    columnNumber: 5
  }, this);
}
_s(OrderTableRow, "yrxKoV3G2eFI3OuvhIxlMBSpVuk=", false, function() {
  return [useQueryClient, useMutation, useMutation, useMutation, useMutation];
});
_c = OrderTableRow;
var _c;
$RefreshReg$(_c, "OrderTableRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-row.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZjOzJCQTdGZDtBQUFvQixNQUFFQSxjQUFjLE9BQVEsc0JBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ25FLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFlBQVlDLFFBQVFDLFNBQVM7QUFDdEMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFFBQVFDLHFCQUFxQjtBQUN0QyxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFFcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG9CQUFvQjtBQVl0QixnQkFBU0MsY0FBYyxFQUFFQyxNQUEwQixHQUFHO0FBQUFDLEtBQUE7QUFDM0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWhCLFNBQVMsS0FBSztBQUN4RCxRQUFNaUIsY0FBY3ZCLGVBQWU7QUFFbkMsV0FBU3dCLHlCQUF5QkMsU0FBaUJDLFFBQXFCO0FBQ3RFLFVBQU1DLGtCQUFrQkosWUFBWUssZUFBa0M7QUFBQSxNQUNwRUMsVUFBVSxDQUFDLFFBQVE7QUFBQSxJQUNyQixDQUFDO0FBRURGLG9CQUFnQkcsUUFBUSxDQUFDLENBQUNDLFVBQVVDLFNBQVMsTUFBTTtBQUNqRCxVQUFJLENBQUNBLFdBQVc7QUFDZDtBQUFBLE1BQ0Y7QUFFQVQsa0JBQVlVLGFBQWdDRixVQUFVO0FBQUEsUUFDcEQsR0FBR0M7QUFBQUEsUUFDSEUsUUFBUUYsVUFBVUUsT0FBT0MsSUFBSSxDQUFDaEIsV0FBVTtBQUN0QyxjQUFJQSxPQUFNTSxZQUFZQSxTQUFTO0FBQzdCLG1CQUFPLEVBQUUsR0FBR04sUUFBT08sT0FBTztBQUFBLFVBQzVCO0FBQ0EsaUJBQU9QO0FBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNLEVBQUVpQixhQUFhQyxlQUFlQyxXQUFXQyxpQkFBaUIsSUFDOURDLFlBQVk7QUFBQSxJQUNWQyxZQUFZakM7QUFBQUEsSUFDWixNQUFNa0MsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCwrQkFBeUJDLFNBQVMsVUFBVTtBQUFBLElBQzlDO0FBQUEsRUFDRixDQUFDO0FBRUgsUUFBTSxFQUFFVyxhQUFhUSxnQkFBZ0JOLFdBQVdPLGlCQUFpQixJQUMvREwsWUFBWTtBQUFBLElBQ1ZDLFlBQVlsQztBQUFBQSxJQUNaLE1BQU1tQyxVQUFVQyxHQUFHLEVBQUVsQixRQUFRLEdBQUc7QUFDOUJELCtCQUF5QkMsU0FBUyxZQUFZO0FBQUEsSUFDaEQ7QUFBQSxFQUNGLENBQUM7QUFHSCxRQUFNLEVBQUVXLGFBQWFVLGlCQUFpQlIsV0FBV1MsbUJBQW1CLElBQ2xFUCxZQUFZO0FBQUEsSUFDVkMsWUFBWS9CO0FBQUFBLElBQ1osTUFBTWdDLFVBQVVDLEdBQUcsRUFBRWxCLFFBQVEsR0FBRztBQUM5QkQsK0JBQXlCQyxTQUFTLFlBQVk7QUFBQSxJQUNoRDtBQUFBLEVBQ0YsQ0FBQztBQUVILFFBQU0sRUFBRVcsYUFBYVksZ0JBQWdCVixXQUFXVyxrQkFBa0IsSUFDaEVULFlBQVk7QUFBQSxJQUNWQyxZQUFZaEM7QUFBQUEsSUFDWixNQUFNaUMsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCwrQkFBeUJDLFNBQVMsV0FBVztBQUFBLElBQy9DO0FBQUEsRUFDRixDQUFDO0FBRUgsU0FDRSx1QkFBQyxZQUNDO0FBQUEsMkJBQUMsYUFDQyxpQ0FBQyxVQUFPLE1BQU1KLGVBQWUsY0FBY0Msa0JBQ3pDO0FBQUEsNkJBQUMsaUJBQWMsU0FBTyxNQUNwQixpQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQzdCO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMzQix1QkFBQyxVQUFLLFdBQVUsV0FBVSxrQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFdBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsZ0JBQWEsTUFBTUQsZUFBZSxTQUFTRixNQUFNTSxXQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FQNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxhQUFVLFdBQVUsaUNBQ2xCTixnQkFBTU0sV0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGFBQVUsV0FBVSx5QkFDbEJ4Qiw4QkFBb0JrQixNQUFNK0IsV0FBVztBQUFBLE1BQ3BDQyxRQUFRakQ7QUFBQUEsTUFDUmtELFdBQVc7QUFBQSxJQUNiLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGFBQ0MsaUNBQUMsZUFBWSxRQUFRakMsTUFBTU8sVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGFBQVUsV0FBVSxlQUFlUCxnQkFBTWtDLGdCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFDdkQsdUJBQUMsYUFBVSxXQUFVLGVBQ2pCbEMsaUJBQU1tQyxRQUFRLEtBQUtDLGVBQWUsU0FBUztBQUFBLE1BQzNDQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLElBQ1osQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsYUFDRXRDO0FBQUFBLFlBQU1PLFdBQVcsYUFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWtCLGVBQWUsRUFBRW5CLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFVBQ3hELFVBQVVvQjtBQUFBQSxVQUNWLFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUVMO0FBQUEsbUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFOekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxNQUdEMUIsTUFBTU8sV0FBVyxnQkFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTW9CLGdCQUFnQixFQUFFckIsU0FBU04sTUFBTU0sUUFBUSxDQUFDO0FBQUEsVUFDekQsVUFBVXNCO0FBQUFBLFVBQ1YsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBRUw7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLE1BRUQ1QixNQUFNTyxXQUFXLGdCQUNoQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNc0IsZUFBZSxFQUFFdkIsU0FBU04sTUFBTU0sUUFBUSxDQUFDO0FBQUEsVUFDeEQsVUFBVXdCO0FBQUFBLFVBQ1YsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBRUw7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLFNBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQ0E7QUFBQSxJQUNBLHVCQUFDLGFBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFVBQ0UsQ0FBQyxDQUFDLFdBQVcsWUFBWSxFQUFFUyxTQUFTdkMsTUFBTU8sTUFBTSxLQUNoRGE7QUFBQUEsUUFFRixTQUFTLE1BQU1GLGNBQWMsRUFBRVosU0FBU04sTUFBTU0sUUFBUSxDQUFDO0FBQUEsUUFDdkQsU0FBUTtBQUFBLFFBQ1IsTUFBSztBQUFBLFFBRUw7QUFBQSxpQ0FBQyxLQUFFLFdBQVUsa0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUFHO0FBQUE7QUFBQTtBQUFBLE1BVGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlGQTtBQUVKO0FBQUNMLEdBL0llRixlQUFhO0FBQUEsVUFFUGxCLGdCQXlCbEJ3QyxhQVFBQSxhQVNBQSxhQVFBQSxXQUFXO0FBQUE7QUFBQW1CLEtBcERDekM7QUFBYSxJQUFBeUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5Q2xpZW50IiwiZm9ybWF0RGlzdGFuY2VUb05vdyIsInB0QlIiLCJBcnJvd1JpZ2h0IiwiU2VhcmNoIiwiWCIsInVzZVN0YXRlIiwiYXBwcm92ZU9yZGVyIiwiY2FuY2VsT3JkZXIiLCJkZWxpdmVyT3JkZXIiLCJkaXNwYXRjaE9yZGVyIiwiQnV0dG9uIiwiRGlhbG9nIiwiRGlhbG9nVHJpZ2dlciIsIlRhYmxlQ2VsbCIsIlRhYmxlUm93IiwiT3JkZXJTdGF0dXMiLCJPcmRlckRldGFpbHMiLCJPcmRlclRhYmxlUm93Iiwib3JkZXIiLCJfcyIsImlzRGV0YWlsc09wZW4iLCJzZXRJc0RldGFpbHNPcGVuIiwicXVlcnlDbGllbnQiLCJ1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUiLCJvcmRlcklkIiwic3RhdHVzIiwib3JkZXJzTGlzdENhY2hlIiwiZ2V0UXVlcmllc0RhdGEiLCJxdWVyeUtleSIsImZvckVhY2giLCJjYWNoZUtleSIsImNhY2hlRGF0YSIsInNldFF1ZXJ5RGF0YSIsIm9yZGVycyIsIm1hcCIsIm11dGF0ZUFzeW5jIiwiY2FuY2VsT3JkZXJGbiIsImlzUGVuZGluZyIsImlzQ2FuY2VsaW5nT3JkZXIiLCJ1c2VNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJfIiwiYXBwcm92ZU9yZGVyRm4iLCJpc0FwcHJvdmluZ09yZGVyIiwiZGlzcGF0Y2hPcmRlckZuIiwiaXNEaXNwYXRjaGluZ09yZGVyIiwiZGVsaXZlck9yZGVyRm4iLCJpc0RlbGl2ZXJpbmdPcmRlciIsImNyZWF0ZWRBdCIsImxvY2FsZSIsImFkZFN1ZmZpeCIsImN1c3RvbWVyTmFtZSIsInRvdGFsIiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiaW5jbHVkZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXRhYmxlLXJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBmb3JtYXREaXN0YW5jZVRvTm93IH0gZnJvbSAnZGF0ZS1mbnMnXHJcbmltcG9ydCB7IHB0QlIgfSBmcm9tICdkYXRlLWZucy9sb2NhbGUnXHJcbmltcG9ydCB7IEFycm93UmlnaHQsIFNlYXJjaCwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuXHJcbmltcG9ydCB7IGFwcHJvdmVPcmRlciB9IGZyb20gJ0AvYXBpL2FwcHJvdmUtb3JkZXInXHJcbmltcG9ydCB7IGNhbmNlbE9yZGVyIH0gZnJvbSAnQC9hcGkvY2FuY2VsLW9yZGVyJ1xyXG5pbXBvcnQgeyBkZWxpdmVyT3JkZXIgfSBmcm9tICdAL2FwaS9kZWxpdmVyLW9yZGVyJ1xyXG5pbXBvcnQgeyBkaXNwYXRjaE9yZGVyIH0gZnJvbSAnQC9hcGkvZGlzcGF0Y2gtb3JkZXInXHJcbmltcG9ydCB7IEdldE9yZGVyc1Jlc3BvbnNlIH0gZnJvbSAnQC9hcGkvZ2V0LW9yZGVycydcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcclxuaW1wb3J0IHsgRGlhbG9nLCBEaWFsb2dUcmlnZ2VyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RpYWxvZydcclxuaW1wb3J0IHsgVGFibGVDZWxsLCBUYWJsZVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcclxuXHJcbmltcG9ydCB7IE9yZGVyU3RhdHVzIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9vcmRlci1zdGF0dXMnXHJcbmltcG9ydCB7IE9yZGVyRGV0YWlscyB9IGZyb20gJy4vb3JkZXItZGV0YWlscydcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJUYWJsZVJvd1Byb3BzIHtcclxuICBvcmRlcjoge1xyXG4gICAgb3JkZXJJZDogc3RyaW5nXHJcbiAgICBjcmVhdGVkQXQ6IHN0cmluZ1xyXG4gICAgc3RhdHVzOiAncGVuZGluZycgfCAnY2FuY2VsZWQnIHwgJ3Byb2Nlc3NpbmcnIHwgJ2RlbGl2ZXJpbmcnIHwgJ2RlbGl2ZXJlZCdcclxuICAgIGN1c3RvbWVyTmFtZTogc3RyaW5nXHJcbiAgICB0b3RhbDogbnVtYmVyXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJUYWJsZVJvdyh7IG9yZGVyIH06IE9yZGVyVGFibGVSb3dQcm9wcykge1xyXG4gIGNvbnN0IFtpc0RldGFpbHNPcGVuLCBzZXRJc0RldGFpbHNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxyXG5cclxuICBmdW5jdGlvbiB1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUob3JkZXJJZDogc3RyaW5nLCBzdGF0dXM6IE9yZGVyU3RhdHVzKSB7XHJcbiAgICBjb25zdCBvcmRlcnNMaXN0Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyaWVzRGF0YTxHZXRPcmRlcnNSZXNwb25zZT4oe1xyXG4gICAgICBxdWVyeUtleTogWydvcmRlcnMnXSxcclxuICAgIH0pXHJcblxyXG4gICAgb3JkZXJzTGlzdENhY2hlLmZvckVhY2goKFtjYWNoZUtleSwgY2FjaGVEYXRhXSkgPT4ge1xyXG4gICAgICBpZiAoIWNhY2hlRGF0YSkge1xyXG4gICAgICAgIHJldHVyblxyXG4gICAgICB9XHJcblxyXG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8R2V0T3JkZXJzUmVzcG9uc2U+KGNhY2hlS2V5LCB7XHJcbiAgICAgICAgLi4uY2FjaGVEYXRhLFxyXG4gICAgICAgIG9yZGVyczogY2FjaGVEYXRhLm9yZGVycy5tYXAoKG9yZGVyKSA9PiB7XHJcbiAgICAgICAgICBpZiAob3JkZXIub3JkZXJJZCA9PT0gb3JkZXJJZCkge1xyXG4gICAgICAgICAgICByZXR1cm4geyAuLi5vcmRlciwgc3RhdHVzIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiBvcmRlclxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGNhbmNlbE9yZGVyRm4sIGlzUGVuZGluZzogaXNDYW5jZWxpbmdPcmRlciB9ID1cclxuICAgIHVzZU11dGF0aW9uKHtcclxuICAgICAgbXV0YXRpb25GbjogY2FuY2VsT3JkZXIsXHJcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xyXG4gICAgICAgIHVwZGF0ZU9yZGVyU3RhdHVzT25DYWNoZShvcmRlcklkLCAnY2FuY2VsZWQnKVxyXG4gICAgICB9LFxyXG4gICAgfSlcclxuXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogYXBwcm92ZU9yZGVyRm4sIGlzUGVuZGluZzogaXNBcHByb3ZpbmdPcmRlciB9ID1cclxuICAgIHVzZU11dGF0aW9uKHtcclxuICAgICAgbXV0YXRpb25GbjogYXBwcm92ZU9yZGVyLFxyXG4gICAgICBhc3luYyBvblN1Y2Nlc3MoXywgeyBvcmRlcklkIH0pIHtcclxuICAgICAgICB1cGRhdGVPcmRlclN0YXR1c09uQ2FjaGUob3JkZXJJZCwgJ3Byb2Nlc3NpbmcnKVxyXG4gICAgICB9LFxyXG4gICAgfSlcclxuXHJcbiAgLy8gcGVuZGluZywgcHJvY2Vzc2luZywgZGVsaXZlcmluZywgZGVsaXZlcmVkXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogZGlzcGF0Y2hPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGlzcGF0Y2hpbmdPcmRlciB9ID1cclxuICAgIHVzZU11dGF0aW9uKHtcclxuICAgICAgbXV0YXRpb25GbjogZGlzcGF0Y2hPcmRlcixcclxuICAgICAgYXN5bmMgb25TdWNjZXNzKF8sIHsgb3JkZXJJZCB9KSB7XHJcbiAgICAgICAgdXBkYXRlT3JkZXJTdGF0dXNPbkNhY2hlKG9yZGVySWQsICdkZWxpdmVyaW5nJylcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGRlbGl2ZXJPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGVsaXZlcmluZ09yZGVyIH0gPVxyXG4gICAgdXNlTXV0YXRpb24oe1xyXG4gICAgICBtdXRhdGlvbkZuOiBkZWxpdmVyT3JkZXIsXHJcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xyXG4gICAgICAgIHVwZGF0ZU9yZGVyU3RhdHVzT25DYWNoZShvcmRlcklkLCAnZGVsaXZlcmVkJylcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8VGFibGVSb3c+XHJcbiAgICAgIDxUYWJsZUNlbGw+XHJcbiAgICAgICAgPERpYWxvZyBvcGVuPXtpc0RldGFpbHNPcGVufSBvbk9wZW5DaGFuZ2U9e3NldElzRGV0YWlsc09wZW59PlxyXG4gICAgICAgICAgPERpYWxvZ1RyaWdnZXIgYXNDaGlsZD5cclxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIHNpemU9XCJ4c1wiPlxyXG4gICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkRldGFsaGVzIGRvIHBlZGlkbzwvc3Bhbj5cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0RpYWxvZ1RyaWdnZXI+XHJcbiAgICAgICAgICA8T3JkZXJEZXRhaWxzIG9wZW49e2lzRGV0YWlsc09wZW59IG9yZGVySWQ9e29yZGVyLm9yZGVySWR9IC8+XHJcbiAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAge29yZGVyLm9yZGVySWR9XHJcbiAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxyXG4gICAgICAgIHtmb3JtYXREaXN0YW5jZVRvTm93KG9yZGVyLmNyZWF0ZWRBdCwge1xyXG4gICAgICAgICAgbG9jYWxlOiBwdEJSLFxyXG4gICAgICAgICAgYWRkU3VmZml4OiB0cnVlLFxyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgPFRhYmxlQ2VsbD5cclxuICAgICAgICA8T3JkZXJTdGF0dXMgc3RhdHVzPXtvcmRlci5zdGF0dXN9IC8+XHJcbiAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e29yZGVyLmN1c3RvbWVyTmFtZX08L1RhYmxlQ2VsbD5cclxuICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgIHsob3JkZXIudG90YWwgLyAxMDApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcclxuICAgICAgICAgIHN0eWxlOiAnY3VycmVuY3knLFxyXG4gICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgPFRhYmxlQ2VsbD5cclxuICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAncGVuZGluZycgJiYgKFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhcHByb3ZlT3JkZXJGbih7IG9yZGVySWQ6IG9yZGVyLm9yZGVySWQgfSl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0FwcHJvdmluZ09yZGVyfVxyXG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgIHNpemU9XCJ4c1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cIm1yLTIgaC0zIHctM1wiIC8+XHJcbiAgICAgICAgICAgIEFwcm92YXJcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtvcmRlci5zdGF0dXMgPT09ICdwcm9jZXNzaW5nJyAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRpc3BhdGNoT3JkZXJGbih7IG9yZGVySWQ6IG9yZGVyLm9yZGVySWQgfSl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rpc3BhdGNoaW5nT3JkZXJ9XHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwibXItMiBoLTMgdy0zXCIgLz5cclxuICAgICAgICAgICAgRW0gZW50cmVnYVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAnZGVsaXZlcmluZycgJiYgKFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBkZWxpdmVyT3JkZXJGbih7IG9yZGVySWQ6IG9yZGVyLm9yZGVySWQgfSl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0RlbGl2ZXJpbmdPcmRlcn1cclxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICBzaXplPVwieHNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJtci0yIGgtMyB3LTNcIiAvPlxyXG4gICAgICAgICAgICBFbnRyZWd1ZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgIDxUYWJsZUNlbGw+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAhWydwZW5kaW5nJywgJ3Byb2Nlc3NpbmcnXS5pbmNsdWRlcyhvcmRlci5zdGF0dXMpIHx8XHJcbiAgICAgICAgICAgIGlzQ2FuY2VsaW5nT3JkZXJcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNhbmNlbE9yZGVyRm4oeyBvcmRlcklkOiBvcmRlci5vcmRlcklkIH0pfVxyXG4gICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcclxuICAgICAgICAgIHNpemU9XCJ4c1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFggY2xhc3NOYW1lPVwibXItMiBoLTMgdy0zXCIgLz5cclxuICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgPC9UYWJsZVJvdz5cclxuICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BY2VyIE5pdHJvIDUvRGVza3RvcC9yb2NrZXRzZWF0L2lnbml0ZS9yZWFjdC9yZWFjdC00L3Bpenphc2hvcC13ZWIvc3JjL3BhZ2VzL2FwcC9vcmRlcnMvb3JkZXItdGFibGUtcm93LnRzeCJ9