import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/order-status.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const orderStatusMap = {
  pending: "Pendente",
  processing: "Em preparo",
  delivering: "Em entrega",
  delivered: "Entregue",
  canceled: "Cancelado"
};
export function OrderStatus({ status }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
    status === "pending" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-slate-400"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
        lineNumber: 24,
        columnNumber: 7
      },
      this
    ),
    status === "canceled" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-rose-500"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
        lineNumber: 31,
        columnNumber: 7
      },
      this
    ),
    status === "delivered" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-emerald-500"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
        lineNumber: 38,
        columnNumber: 7
      },
      this
    ),
    ["processing", "delivering"].includes(status) && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-amber-500"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
        lineNumber: 45,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-muted-foreground", children: orderStatusMap[status] }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
}
_c = OrderStatus;
var _c;
$RefreshReg$(_c, "OrderStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/order-status.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJRO0FBdkJSLE9BQU8sb0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVd2QixNQUFNQSxpQkFBOEM7QUFBQSxFQUNsREMsU0FBUztBQUFBLEVBQ1RDLFlBQVk7QUFBQSxFQUNaQyxZQUFZO0FBQUEsRUFDWkMsV0FBVztBQUFBLEVBQ1hDLFVBQVU7QUFDWjtBQUVPLGdCQUFTQyxZQUFZLEVBQUVDLE9BQXlCLEdBQUc7QUFDeEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pBO0FBQUFBLGVBQVcsYUFDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFK0M7QUFBQSxJQUloREEsV0FBVyxjQUNWO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxlQUFZO0FBQUEsUUFDWixXQUFVO0FBQUE7QUFBQSxNQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU4QztBQUFBLElBSS9DQSxXQUFXLGVBQ1Y7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGVBQVk7QUFBQSxRQUNaLFdBQVU7QUFBQTtBQUFBLE1BRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRWlEO0FBQUEsSUFJbEQsQ0FBQyxjQUFjLFlBQVksRUFBRUMsU0FBU0QsTUFBTSxLQUMzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFK0M7QUFBQSxJQUlqRCx1QkFBQyxVQUFLLFdBQVUscUNBQ2JQLHlCQUFlTyxNQUFNLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDRSxLQXBDZUg7QUFBVyxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsib3JkZXJTdGF0dXNNYXAiLCJwZW5kaW5nIiwicHJvY2Vzc2luZyIsImRlbGl2ZXJpbmciLCJkZWxpdmVyZWQiLCJjYW5jZWxlZCIsIk9yZGVyU3RhdHVzIiwic3RhdHVzIiwiaW5jbHVkZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXN0YXR1cy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHR5cGUgT3JkZXJTdGF0dXMgPVxyXG4gIHwgJ3BlbmRpbmcnXHJcbiAgfCAnY2FuY2VsZWQnXHJcbiAgfCAncHJvY2Vzc2luZydcclxuICB8ICdkZWxpdmVyaW5nJ1xyXG4gIHwgJ2RlbGl2ZXJlZCdcclxuXHJcbmludGVyZmFjZSBPcmRlclN0YXR1c1Byb3BzIHtcclxuICBzdGF0dXM6IE9yZGVyU3RhdHVzXHJcbn1cclxuXHJcbmNvbnN0IG9yZGVyU3RhdHVzTWFwOiBSZWNvcmQ8T3JkZXJTdGF0dXMsIHN0cmluZz4gPSB7XHJcbiAgcGVuZGluZzogJ1BlbmRlbnRlJyxcclxuICBwcm9jZXNzaW5nOiAnRW0gcHJlcGFybycsXHJcbiAgZGVsaXZlcmluZzogJ0VtIGVudHJlZ2EnLFxyXG4gIGRlbGl2ZXJlZDogJ0VudHJlZ3VlJyxcclxuICBjYW5jZWxlZDogJ0NhbmNlbGFkbycsXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlclN0YXR1cyh7IHN0YXR1cyB9OiBPcmRlclN0YXR1c1Byb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAge3N0YXR1cyA9PT0gJ3BlbmRpbmcnICYmIChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS00MDBcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7c3RhdHVzID09PSAnY2FuY2VsZWQnICYmIChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTUwMFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtzdGF0dXMgPT09ICdkZWxpdmVyZWQnICYmIChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtbJ3Byb2Nlc3NpbmcnLCAnZGVsaXZlcmluZyddLmluY2x1ZGVzKHN0YXR1cykgJiYgKFxyXG4gICAgICAgIDxzcGFuXHJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImJhZGdlXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwMFwiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxyXG4gICAgICAgIHtvcmRlclN0YXR1c01hcFtzdGF0dXNdfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BY2VyIE5pdHJvIDUvRGVza3RvcC9yb2NrZXRzZWF0L2lnbml0ZS9yZWFjdC9yZWFjdC00L3Bpenphc2hvcC13ZWIvc3JjL2NvbXBvbmVudHMvb3JkZXItc3RhdHVzLnRzeCJ9