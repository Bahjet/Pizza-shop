import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/dashboard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=12cb1194";
import { DayOrdersAmountCard } from "/src/pages/app/dashboard/day-orders-amount-card.tsx";
import { MonthCanceledOrdersAmountCard } from "/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx";
import { MonthOrdersAmountCard } from "/src/pages/app/dashboard/month-orders-amount-card.tsx";
import { MonthRevenueCard } from "/src/pages/app/dashboard/month-revenue-card.tsx";
import { PopularProductsChart } from "/src/pages/app/dashboard/popular-products-chart.tsx?t=1713839676892";
import { RevenueChart } from "/src/pages/app/dashboard/revenue-chart.tsx";
export function Dashboard() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Dashboard" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold tracking-tight", children: "Dashboard" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV(MonthRevenueCard, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 17,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(MonthOrdersAmountCard, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 18,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DayOrdersAmountCard, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 19,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(MonthCanceledOrdersAmountCard, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 20,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-9 gap-4", children: [
        /* @__PURE__ */ jsxDEV(RevenueChart, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 24,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(PopularProductsChart, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
          lineNumber: 25,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
}
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/dashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV0ksbUJBQ0UsY0FERjtBQVhKLDJCQUF1QjtBQUFvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFM0MsU0FBU0EsMkJBQTJCO0FBQ3BDLFNBQVNDLHFDQUFxQztBQUM5QyxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0Msd0JBQXdCO0FBQ2pDLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxvQkFBb0I7QUFFdEIsZ0JBQVNDLFlBQVk7QUFDMUIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFVBQU8sT0FBTSxlQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUscUNBQW9DLHlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsK0JBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQSxRQUN0Qix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFDcEIsdUJBQUMsbUNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBSmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsK0JBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYix1QkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsV0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDQyxLQXBCZUQ7QUFBUyxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRGF5T3JkZXJzQW1vdW50Q2FyZCIsIk1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnRDYXJkIiwiTW9udGhPcmRlcnNBbW91bnRDYXJkIiwiTW9udGhSZXZlbnVlQ2FyZCIsIlBvcHVsYXJQcm9kdWN0c0NoYXJ0IiwiUmV2ZW51ZUNoYXJ0IiwiRGFzaGJvYXJkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJkYXNoYm9hcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldC1hc3luYydcclxuXHJcbmltcG9ydCB7IERheU9yZGVyc0Ftb3VudENhcmQgfSBmcm9tICcuL2RheS1vcmRlcnMtYW1vdW50LWNhcmQnXHJcbmltcG9ydCB7IE1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnRDYXJkIH0gZnJvbSAnLi9tb250aC1jYW5jZWxlZC1vcmRlcnMtYW1vdW50LWNhcmQnXHJcbmltcG9ydCB7IE1vbnRoT3JkZXJzQW1vdW50Q2FyZCB9IGZyb20gJy4vbW9udGgtb3JkZXJzLWFtb3VudC1jYXJkJ1xyXG5pbXBvcnQgeyBNb250aFJldmVudWVDYXJkIH0gZnJvbSAnLi9tb250aC1yZXZlbnVlLWNhcmQnXHJcbmltcG9ydCB7IFBvcHVsYXJQcm9kdWN0c0NoYXJ0IH0gZnJvbSAnLi9wb3B1bGFyLXByb2R1Y3RzLWNoYXJ0J1xyXG5pbXBvcnQgeyBSZXZlbnVlQ2hhcnQgfSBmcm9tICcuL3JldmVudWUtY2hhcnQnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8SGVsbWV0IHRpdGxlPVwiRGFzaGJvYXJkXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPkRhc2hib2FyZDwvaDE+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICA8TW9udGhSZXZlbnVlQ2FyZCAvPlxyXG4gICAgICAgICAgPE1vbnRoT3JkZXJzQW1vdW50Q2FyZCAvPlxyXG4gICAgICAgICAgPERheU9yZGVyc0Ftb3VudENhcmQgLz5cclxuICAgICAgICAgIDxNb250aENhbmNlbGVkT3JkZXJzQW1vdW50Q2FyZCAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTkgZ2FwLTRcIj5cclxuICAgICAgICAgIDxSZXZlbnVlQ2hhcnQgLz5cclxuICAgICAgICAgIDxQb3B1bGFyUHJvZHVjdHNDaGFydCAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9kYXNoYm9hcmQudHN4In0=