import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/pagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { Button } from "/src/components/ui/button.tsx";
export function Pagination({
  pageIndex,
  totalCount,
  perPage,
  onPageChange
}) {
  const pages = Math.ceil(totalCount / perPage) || 1;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-muted-foreground", children: [
      "Total de ",
      totalCount,
      " item(s)"
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 lg:gap-8", children: /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium", children: [
      "Página ",
      pageIndex + 1,
      " de ",
      pages,
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(0),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 41,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Primeira página" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 42,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
            lineNumber: 35,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pageIndex - 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 50,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Página anterior" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 51,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
            lineNumber: 44,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pageIndex + 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 59,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Próxima página" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 60,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
            lineNumber: 53,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pages - 1),
            variant: "outline",
            className: "h-8 w-8 p-0",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 68,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Última página" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
                lineNumber: 69,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
            lineNumber: 62,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
        lineNumber: 34,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJNO0FBMUJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLGNBQWM7QUFTaEIsZ0JBQVNDLFdBQVc7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxHQUFHO0FBQ2xCLFFBQU1DLFFBQVFDLEtBQUtDLEtBQUtMLGFBQWFDLE9BQU8sS0FBSztBQUVqRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLE1BQ3BDRDtBQUFBQSxNQUFXO0FBQUEsU0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2IsaUNBQUMsU0FBSSxXQUFVLHVCQUFzQjtBQUFBO0FBQUEsTUFDM0JELFlBQVk7QUFBQSxNQUFFO0FBQUEsTUFBS0k7QUFBQUEsTUFDM0IsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUQsYUFBYSxDQUFDO0FBQUEsWUFDN0IsU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBLFlBQ1YsVUFBVUgsY0FBYztBQUFBLFlBRXhCO0FBQUEscUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQ2pDLHVCQUFDLFVBQUssV0FBVSxXQUFVLCtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBO0FBQUE7QUFBQSxVQVAzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUcsYUFBYUgsWUFBWSxDQUFDO0FBQUEsWUFDekMsU0FBUTtBQUFBLFlBQ1IsV0FBVTtBQUFBLFlBQ1YsVUFBVUEsY0FBYztBQUFBLFlBRXhCO0FBQUEscUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FDaEMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsK0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUE7QUFBQTtBQUFBLFVBUDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNRyxhQUFhSCxZQUFZLENBQUM7QUFBQSxZQUN6QyxTQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFDVixVQUFVSSxTQUFTSixZQUFZO0FBQUEsWUFFL0I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsOEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUE7QUFBQTtBQUFBLFVBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNRyxhQUFhQyxRQUFRLENBQUM7QUFBQSxZQUNyQyxTQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFDVixVQUFVQSxTQUFTSixZQUFZO0FBQUEsWUFFL0I7QUFBQSxxQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsNkJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUE7QUFBQTtBQUFBLFVBUHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVFBO0FBQUEsV0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLFNBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLE9BL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFSjtBQUFDTyxLQTNEZVI7QUFBVSxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJDaGV2cm9uc0xlZnQiLCJDaGV2cm9uc1JpZ2h0IiwiQnV0dG9uIiwiUGFnaW5hdGlvbiIsInBhZ2VJbmRleCIsInRvdGFsQ291bnQiLCJwZXJQYWdlIiwib25QYWdlQ2hhbmdlIiwicGFnZXMiLCJNYXRoIiwiY2VpbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicGFnaW5hdGlvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBDaGV2cm9uTGVmdCxcclxuICBDaGV2cm9uUmlnaHQsXHJcbiAgQ2hldnJvbnNMZWZ0LFxyXG4gIENoZXZyb25zUmlnaHQsXHJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5cclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi91aS9idXR0b24nXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFBhZ2luYXRpb25Qcm9wcyB7XHJcbiAgcGFnZUluZGV4OiBudW1iZXJcclxuICB0b3RhbENvdW50OiBudW1iZXJcclxuICBwZXJQYWdlOiBudW1iZXJcclxuICBvblBhZ2VDaGFuZ2U6IChwYWdlSW5kZXg6IG51bWJlcikgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWRcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFBhZ2luYXRpb24oe1xyXG4gIHBhZ2VJbmRleCxcclxuICB0b3RhbENvdW50LFxyXG4gIHBlclBhZ2UsXHJcbiAgb25QYWdlQ2hhbmdlLFxyXG59OiBQYWdpbmF0aW9uUHJvcHMpIHtcclxuICBjb25zdCBwYWdlcyA9IE1hdGguY2VpbCh0b3RhbENvdW50IC8gcGVyUGFnZSkgfHwgMVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cclxuICAgICAgICBUb3RhbCBkZSB7dG90YWxDb3VudH0gaXRlbShzKVxyXG4gICAgICA8L3NwYW4+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02IGxnOmdhcC04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICBQw6FnaW5hIHtwYWdlSW5kZXggKyAxfSBkZSB7cGFnZXN9XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UoMCl9XHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LTggcC0wXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZUluZGV4ID09PSAwfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPENoZXZyb25zTGVmdCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UHJpbWVpcmEgcMOhZ2luYTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UocGFnZUluZGV4IC0gMSl9XHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LTggcC0wXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZUluZGV4ID09PSAwfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Qw6FnaW5hIGFudGVyaW9yPC9zcGFuPlxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShwYWdlSW5kZXggKyAxKX1cclxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlcyA8PSBwYWdlSW5kZXggKyAxfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UHLDs3hpbWEgcMOhZ2luYTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UocGFnZXMgLSAxKX1cclxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCBwLTBcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlcyA8PSBwYWdlSW5kZXggKyAxfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPENoZXZyb25zUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPsOabHRpbWEgcMOhZ2luYTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BY2VyIE5pdHJvIDUvRGVza3RvcC9yb2NrZXRzZWF0L2lnbml0ZS9yZWFjdC9yZWFjdC00L3Bpenphc2hvcC13ZWIvc3JjL2NvbXBvbmVudHMvcGFnaW5hdGlvbi50c3gifQ==