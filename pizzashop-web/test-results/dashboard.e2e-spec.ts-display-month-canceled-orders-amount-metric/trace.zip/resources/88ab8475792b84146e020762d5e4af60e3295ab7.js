import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/revenue-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { subDays } from "/node_modules/.vite/deps/date-fns.js?v=12cb1194";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=12cb1194"; const useMemo = __vite__cjsImport6_react["useMemo"]; const useState = __vite__cjsImport6_react["useState"];
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis
} from "/node_modules/.vite/deps/recharts.js?v=12cb1194";
import __vite__cjsImport8_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=12cb1194"; const colors = __vite__cjsImport8_tailwindcss_colors.__esModule ? __vite__cjsImport8_tailwindcss_colors.default : __vite__cjsImport8_tailwindcss_colors;
import { getDailyRevenueInPeriod } from "/src/api/get-daily-revenue-in-period.ts";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "/src/components/ui/card.tsx";
import { DateRangePicker } from "/src/components/ui/date-range-picker.tsx";
import { Label } from "/src/components/ui/label.tsx";
export function RevenueChart() {
  _s();
  const [dateRange, setDateRange] = useState({
    from: subDays(/* @__PURE__ */ new Date(), 7),
    to: /* @__PURE__ */ new Date()
  });
  const { data: dailyRevenueInPeriod } = useQuery({
    queryKey: ["metrics", "daily-revenue-in-period", dateRange],
    queryFn: () => getDailyRevenueInPeriod({
      from: dateRange?.from,
      to: dateRange?.to
    })
  });
  const charData = useMemo(() => {
    return dailyRevenueInPeriod?.map((chartItem) => {
      return {
        date: chartItem.date,
        receipt: chartItem.receipt / 100
      };
    });
  }, [dailyRevenueInPeriod]);
  return /* @__PURE__ */ jsxDEV(Card, { className: "col-span-6", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between pb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Receita no período" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(CardDescription, { children: "Receita diária no período" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Período" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DateRangePicker, { date: dateRange, onDateChange: setDateRange }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 64,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: charData ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(LineChart, { data: charData, style: { fontSize: 12 }, children: [
      /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "date", tickLine: false, axisLine: false, dy: 16 }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 71,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        YAxis,
        {
          stroke: "#888",
          axisLine: false,
          tickLine: false,
          width: 80,
          tickFormatter: (value) => value.toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
          })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 73,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(CartesianGrid, { vertical: false, className: "stroke-muted" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 86,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          type: "linear",
          strokeWidth: 2,
          dataKey: "receipt",
          stroke: colors.violet["500"]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 88,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 70,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 69,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 98,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 97,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 67,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(RevenueChart, "DlDOyuU5rwsPomZxJiqJruh51a8=", false, function() {
  return [useQuery];
});
_c = RevenueChart;
var _c;
$RefreshReg$(_c, "RevenueChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/revenue-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RVOzJCQXREVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBRWxDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFlBQVk7QUFFbkIsU0FBU0MsK0JBQStCO0FBQ3hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxhQUFhO0FBRWYsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSW5CLFNBQWdDO0FBQUEsSUFDaEVvQixNQUFNdkIsUUFBUSxvQkFBSXdCLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDM0JDLElBQUksb0JBQUlELEtBQUs7QUFBQSxFQUNmLENBQUM7QUFFRCxRQUFNLEVBQUVFLE1BQU1DLHFCQUFxQixJQUFJQyxTQUFTO0FBQUEsSUFDOUNDLFVBQVUsQ0FBQyxXQUFXLDJCQUEyQlIsU0FBUztBQUFBLElBQzFEUyxTQUFTQSxNQUNQbkIsd0JBQXdCO0FBQUEsTUFDdEJZLE1BQU1GLFdBQVdFO0FBQUFBLE1BQ2pCRSxJQUFJSixXQUFXSTtBQUFBQSxJQUNqQixDQUFDO0FBQUEsRUFDTCxDQUFDO0FBRUQsUUFBTU0sV0FBVzdCLFFBQVEsTUFBTTtBQUM3QixXQUFPeUIsc0JBQXNCSyxJQUFJLENBQUNDLGNBQWM7QUFDOUMsYUFBTztBQUFBLFFBQ0xDLE1BQU1ELFVBQVVDO0FBQUFBLFFBQ2hCQyxTQUFTRixVQUFVRSxVQUFVO0FBQUEsTUFDL0I7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ1Isb0JBQW9CLENBQUM7QUFFekIsU0FDRSx1QkFBQyxRQUFLLFdBQVUsY0FDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSw4Q0FDcEI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLGFBQVUsV0FBVSx5QkFBd0Isa0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsbUJBQWdCLHlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBRWQsdUJBQUMsbUJBQWdCLE1BQU1OLFdBQVcsY0FBY0MsZ0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUgvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBQ0EsdUJBQUMsZUFDRVMscUJBQ0MsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLGFBQVUsTUFBTUEsVUFBVSxPQUFPLEVBQUVLLFVBQVUsR0FBRyxHQUMvQztBQUFBLDZCQUFDLFNBQU0sU0FBUSxRQUFPLFVBQVUsT0FBTyxVQUFVLE9BQU8sSUFBSSxNQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStEO0FBQUEsTUFFL0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFFBQU87QUFBQSxVQUNQLFVBQVU7QUFBQSxVQUNWLFVBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxVQUNQLGVBQWUsQ0FBQ0MsVUFDZEEsTUFBTUMsZUFBZSxTQUFTO0FBQUEsWUFDNUJDLE9BQU87QUFBQSxZQUNQQyxVQUFVO0FBQUEsVUFDWixDQUFDO0FBQUE7QUFBQSxRQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVHO0FBQUEsTUFHSCx1QkFBQyxpQkFBYyxVQUFVLE9BQU8sV0FBVSxrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLE1BRXhEO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxhQUFhO0FBQUEsVUFDYixTQUFRO0FBQUEsVUFDUixRQUFROUIsT0FBTytCLE9BQU8sS0FBSztBQUFBO0FBQUEsUUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStCO0FBQUEsU0F0QmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYixpQ0FBQyxXQUFRLFdBQVUsZ0RBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0QsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxPQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0RBO0FBRUo7QUFBQ3JCLEdBN0VlRCxjQUFZO0FBQUEsVUFNYVMsUUFBUTtBQUFBO0FBQUFjLEtBTmpDdkI7QUFBWSxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN1YkRheXMiLCJMb2FkZXIyIiwidXNlTWVtbyIsInVzZVN0YXRlIiwiQ2FydGVzaWFuR3JpZCIsIkxpbmUiLCJMaW5lQ2hhcnQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiWEF4aXMiLCJZQXhpcyIsImNvbG9ycyIsImdldERhaWx5UmV2ZW51ZUluUGVyaW9kIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZERlc2NyaXB0aW9uIiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIkRhdGVSYW5nZVBpY2tlciIsIkxhYmVsIiwiUmV2ZW51ZUNoYXJ0IiwiX3MiLCJkYXRlUmFuZ2UiLCJzZXREYXRlUmFuZ2UiLCJmcm9tIiwiRGF0ZSIsInRvIiwiZGF0YSIsImRhaWx5UmV2ZW51ZUluUGVyaW9kIiwidXNlUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJjaGFyRGF0YSIsIm1hcCIsImNoYXJ0SXRlbSIsImRhdGUiLCJyZWNlaXB0IiwiZm9udFNpemUiLCJ2YWx1ZSIsInRvTG9jYWxlU3RyaW5nIiwic3R5bGUiLCJjdXJyZW5jeSIsInZpb2xldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicmV2ZW51ZS1jaGFydC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IHN1YkRheXMgfSBmcm9tICdkYXRlLWZucydcclxuaW1wb3J0IHsgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgRGF0ZVJhbmdlIH0gZnJvbSAncmVhY3QtZGF5LXBpY2tlcidcclxuaW1wb3J0IHtcclxuICBDYXJ0ZXNpYW5HcmlkLFxyXG4gIExpbmUsXHJcbiAgTGluZUNoYXJ0LFxyXG4gIFJlc3BvbnNpdmVDb250YWluZXIsXHJcbiAgWEF4aXMsXHJcbiAgWUF4aXMsXHJcbn0gZnJvbSAncmVjaGFydHMnXHJcbmltcG9ydCBjb2xvcnMgZnJvbSAndGFpbHdpbmRjc3MvY29sb3JzJ1xyXG5cclxuaW1wb3J0IHsgZ2V0RGFpbHlSZXZlbnVlSW5QZXJpb2QgfSBmcm9tICdAL2FwaS9nZXQtZGFpbHktcmV2ZW51ZS1pbi1wZXJpb2QnXHJcbmltcG9ydCB7XHJcbiAgQ2FyZCxcclxuICBDYXJkQ29udGVudCxcclxuICBDYXJkRGVzY3JpcHRpb24sXHJcbiAgQ2FyZEhlYWRlcixcclxuICBDYXJkVGl0bGUsXHJcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXHJcbmltcG9ydCB7IERhdGVSYW5nZVBpY2tlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9kYXRlLXJhbmdlLXBpY2tlcidcclxuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvbGFiZWwnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmV2ZW51ZUNoYXJ0KCkge1xyXG4gIGNvbnN0IFtkYXRlUmFuZ2UsIHNldERhdGVSYW5nZV0gPSB1c2VTdGF0ZTxEYXRlUmFuZ2UgfCB1bmRlZmluZWQ+KHtcclxuICAgIGZyb206IHN1YkRheXMobmV3IERhdGUoKSwgNyksXHJcbiAgICB0bzogbmV3IERhdGUoKSxcclxuICB9KVxyXG5cclxuICBjb25zdCB7IGRhdGE6IGRhaWx5UmV2ZW51ZUluUGVyaW9kIH0gPSB1c2VRdWVyeSh7XHJcbiAgICBxdWVyeUtleTogWydtZXRyaWNzJywgJ2RhaWx5LXJldmVudWUtaW4tcGVyaW9kJywgZGF0ZVJhbmdlXSxcclxuICAgIHF1ZXJ5Rm46ICgpID0+XHJcbiAgICAgIGdldERhaWx5UmV2ZW51ZUluUGVyaW9kKHtcclxuICAgICAgICBmcm9tOiBkYXRlUmFuZ2U/LmZyb20sXHJcbiAgICAgICAgdG86IGRhdGVSYW5nZT8udG8sXHJcbiAgICAgIH0pLFxyXG4gIH0pXHJcblxyXG4gIGNvbnN0IGNoYXJEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZGFpbHlSZXZlbnVlSW5QZXJpb2Q/Lm1hcCgoY2hhcnRJdGVtKSA9PiB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgZGF0ZTogY2hhcnRJdGVtLmRhdGUsXHJcbiAgICAgICAgcmVjZWlwdDogY2hhcnRJdGVtLnJlY2VpcHQgLyAxMDAsXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfSwgW2RhaWx5UmV2ZW51ZUluUGVyaW9kXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImNvbC1zcGFuLTZcIj5cclxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgIFJlY2VpdGEgbm8gcGVyw61vZG9cclxuICAgICAgICAgIDwvQ2FyZFRpdGxlPlxyXG4gICAgICAgICAgPENhcmREZXNjcmlwdGlvbj5SZWNlaXRhIGRpw6FyaWEgbm8gcGVyw61vZG88L0NhcmREZXNjcmlwdGlvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgPExhYmVsPlBlcsOtb2RvPC9MYWJlbD5cclxuXHJcbiAgICAgICAgICA8RGF0ZVJhbmdlUGlja2VyIGRhdGU9e2RhdGVSYW5nZX0gb25EYXRlQ2hhbmdlPXtzZXREYXRlUmFuZ2V9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvQ2FyZEhlYWRlcj5cclxuICAgICAgPENhcmRDb250ZW50PlxyXG4gICAgICAgIHtjaGFyRGF0YSA/IChcclxuICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjQwfT5cclxuICAgICAgICAgICAgPExpbmVDaGFydCBkYXRhPXtjaGFyRGF0YX0gc3R5bGU9e3sgZm9udFNpemU6IDEyIH19PlxyXG4gICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwiZGF0ZVwiIHRpY2tMaW5lPXtmYWxzZX0gYXhpc0xpbmU9e2ZhbHNlfSBkeT17MTZ9IC8+XHJcblxyXG4gICAgICAgICAgICAgIDxZQXhpc1xyXG4gICAgICAgICAgICAgICAgc3Ryb2tlPVwiIzg4OFwiXHJcbiAgICAgICAgICAgICAgICBheGlzTGluZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICB0aWNrTGluZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICB3aWR0aD17ODB9XHJcbiAgICAgICAgICAgICAgICB0aWNrRm9ybWF0dGVyPXsodmFsdWU6IG51bWJlcikgPT5cclxuICAgICAgICAgICAgICAgICAgdmFsdWUudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlOiAnY3VycmVuY3knLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbmN5OiAnQlJMJyxcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCB2ZXJ0aWNhbD17ZmFsc2V9IGNsYXNzTmFtZT1cInN0cm9rZS1tdXRlZFwiIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxMaW5lXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibGluZWFyXCJcclxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgZGF0YUtleT1cInJlY2VpcHRcIlxyXG4gICAgICAgICAgICAgICAgc3Ryb2tlPXtjb2xvcnMudmlvbGV0Wyc1MDAnXX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0xpbmVDaGFydD5cclxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtWzI0MHB4XSB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtOCB3LTggYW5pbWF0ZS1zcGluIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgPC9DYXJkPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9yZXZlbnVlLWNoYXJ0LnRzeCJ9