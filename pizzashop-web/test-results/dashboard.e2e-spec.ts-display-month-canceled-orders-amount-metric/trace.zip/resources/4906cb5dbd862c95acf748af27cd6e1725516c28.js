import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/store-profile-dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=12cb1194";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=12cb1194";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=12cb1194";
import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
import {
  getManagedRestaurant
} from "/src/api/get-managed-restaurant.ts?t=1713839672183";
import { updateProfile } from "/src/api/update-profile.ts?t=1713839663772";
import { Button } from "/src/components/ui/button.tsx";
import {
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
const storeProfileSchema = z.object({
  name: z.string().min(1),
  description: z.string().nullable()
});
export function StoreProfileDialog() {
  _s();
  const queryClient = useQueryClient();
  const { data: managedRestaurant } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getManagedRestaurant,
    staleTime: Infinity
  });
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    resolver: zodResolver(storeProfileSchema),
    values: {
      name: managedRestaurant?.name ?? "",
      description: managedRestaurant?.description ?? ""
    }
  });
  function updateManagedRestaurantCache({
    name,
    description
  }) {
    const cached = queryClient.getQueryData(
      [
        "managed-restaurant"
      ]
    );
    if (cached) {
      queryClient.setQueryData(
        ["managed-restaurant"],
        {
          ...cached,
          name,
          description
        }
      );
    }
    return { cached };
  }
  const { mutateAsync: updateProfileFn } = useMutation({
    mutationFn: updateProfile,
    onMutate({ name, description }) {
      const { cached } = updateManagedRestaurantCache({ name, description });
      return { previusProfile: cached };
    },
    onError(_, __, context) {
      if (context?.previusProfile) {
        updateManagedRestaurantCache(context.previusProfile);
      }
    }
  });
  async function handleUpdateProfile(data) {
    try {
      await updateProfileFn({
        name: data.name,
        description: data.description
      });
      toast.success("Perfil atualizado com sucesso");
    } catch {
      toast.error("Falha ao atualizar o perfil, tente novamente!");
    }
  }
  return /* @__PURE__ */ jsxDEV(DialogContent, { children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Perfil da loja" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Atualize as informações do seu estabelecimento visíveis ao seu cliente" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(handleUpdateProfile), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 py-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "name", children: "Nome" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { className: "col-span-3", id: "name", ...register("name") }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
            lineNumber: 117,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "description", children: "Descrição" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
            lineNumber: 120,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              className: "col-span-3",
              id: "description",
              ...register("description")
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
              lineNumber: 123,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(DialogClose, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", type: "button", children: "Cancelar" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
          lineNumber: 132,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
          lineNumber: 131,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "success", disabled: isSubmitting, children: "Salvar" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
          lineNumber: 136,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx",
    lineNumber: 103,
    columnNumber: 5
  }, this);
}
_s(StoreProfileDialog, "Fd+zEhCPd6AzZEo9ppUGZMIGESE=", false, function() {
  return [useQueryClient, useQuery, useForm, useMutation];
});
_c = StoreProfileDialog;
var _c;
$RefreshReg$(_c, "StoreProfileDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/store-profile-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0dROzJCQXhHUjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsYUFBYUMsVUFBVUMsc0JBQXNCO0FBQ3RELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxTQUFTO0FBRWxCO0FBQUEsRUFDRUM7QUFBQUEsT0FFSztBQUNQLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTUMscUJBQXFCYixFQUFFYyxPQUFPO0FBQUEsRUFDbENDLE1BQU1mLEVBQUVnQixPQUFPLEVBQUVDLElBQUksQ0FBQztBQUFBLEVBQ3RCQyxhQUFhbEIsRUFBRWdCLE9BQU8sRUFBRUcsU0FBUztBQUNuQyxDQUFDO0FBSU0sZ0JBQVNDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQ25DLFFBQU1DLGNBQWN6QixlQUFlO0FBRW5DLFFBQU0sRUFBRTBCLE1BQU1DLGtCQUFrQixJQUFJNUIsU0FBUztBQUFBLElBQzNDNkIsVUFBVSxDQUFDLG9CQUFvQjtBQUFBLElBQy9CQyxTQUFTekI7QUFBQUEsSUFDVDBCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxXQUFXLEVBQUVDLGFBQWE7QUFBQSxFQUM1QixJQUFJbEMsUUFBNEI7QUFBQSxJQUM5Qm1DLFVBQVVDLFlBQVlyQixrQkFBa0I7QUFBQSxJQUN4Q3NCLFFBQVE7QUFBQSxNQUNOcEIsTUFBTVMsbUJBQW1CVCxRQUFRO0FBQUEsTUFDakNHLGFBQWFNLG1CQUFtQk4sZUFBZTtBQUFBLElBQ2pEO0FBQUEsRUFDRixDQUFDO0FBRUQsV0FBU2tCLDZCQUE2QjtBQUFBLElBQ3BDckI7QUFBQUEsSUFDQUc7QUFBQUEsRUFDa0IsR0FBRztBQUNyQixVQUFNbUIsU0FBU2YsWUFBWWdCO0FBQUFBLE1BQTJDO0FBQUEsUUFDcEU7QUFBQSxNQUFvQjtBQUFBLElBQ3JCO0FBRUQsUUFBSUQsUUFBUTtBQUNWZixrQkFBWWlCO0FBQUFBLFFBQ1YsQ0FBQyxvQkFBb0I7QUFBQSxRQUNyQjtBQUFBLFVBQ0UsR0FBR0Y7QUFBQUEsVUFDSHRCO0FBQUFBLFVBQ0FHO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sRUFBRW1CLE9BQU87QUFBQSxFQUNsQjtBQUVBLFFBQU0sRUFBRUcsYUFBYUMsZ0JBQWdCLElBQUk5QyxZQUFZO0FBQUEsSUFDbkQrQyxZQUFZeEM7QUFBQUEsSUFDWnlDLFNBQVMsRUFBRTVCLE1BQU1HLFlBQVksR0FBRztBQUM5QixZQUFNLEVBQUVtQixPQUFPLElBQUlELDZCQUE2QixFQUFFckIsTUFBTUcsWUFBWSxDQUFDO0FBRXJFLGFBQU8sRUFBRTBCLGdCQUFnQlAsT0FBTztBQUFBLElBQ2xDO0FBQUEsSUFDQVEsUUFBUUMsR0FBR0MsSUFBSUMsU0FBUztBQUN0QixVQUFJQSxTQUFTSixnQkFBZ0I7QUFDM0JSLHFDQUE2QlksUUFBUUosY0FBYztBQUFBLE1BQ3JEO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELGlCQUFlSyxvQkFBb0IxQixNQUEwQjtBQUMzRCxRQUFJO0FBQ0YsWUFBTWtCLGdCQUFnQjtBQUFBLFFBQ3BCMUIsTUFBTVEsS0FBS1I7QUFBQUEsUUFDWEcsYUFBYUssS0FBS0w7QUFBQUEsTUFDcEIsQ0FBQztBQUVEbkIsWUFBTW1ELFFBQVEsK0JBQStCO0FBQUEsSUFDL0MsUUFBUTtBQUNObkQsWUFBTW9ELE1BQU0sK0NBQStDO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxpQkFDQztBQUFBLDJCQUFDLGdCQUNDO0FBQUEsNkJBQUMsZUFBWSw4QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsTUFDM0IsdUJBQUMscUJBQWtCLHNGQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsVUFBSyxVQUFVckIsYUFBYW1CLG1CQUFtQixHQUM5QztBQUFBLDZCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFNBQU0sV0FBVSxjQUFhLFNBQVEsUUFBTyxvQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxXQUFVLGNBQWEsSUFBRyxRQUFPLEdBQUlwQixTQUFTLE1BQU0sS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQUovRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFNBQU0sV0FBVSxjQUFhLFNBQVEsZUFBYyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILEdBQUlBLFNBQVMsYUFBYTtBQUFBO0FBQUEsWUFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzhCO0FBQUEsYUFQaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLE1BQ0EsdUJBQUMsZ0JBQ0M7QUFBQSwrQkFBQyxlQUFZLFNBQU8sTUFDbEIsaUNBQUMsVUFBTyxTQUFRLFNBQVEsTUFBSyxVQUFTLHdCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxVQUFTLFNBQVEsV0FBVSxVQUFVRyxjQUFjLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxPQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBO0FBRUo7QUFBQ1gsR0E5R2VELG9CQUFrQjtBQUFBLFVBQ1p2QixnQkFFZ0JELFVBVWhDRSxTQTZCcUNILFdBQVc7QUFBQTtBQUFBeUQsS0ExQ3RDaEM7QUFBa0IsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNdXRhdGlvbiIsInVzZVF1ZXJ5IiwidXNlUXVlcnlDbGllbnQiLCJ1c2VGb3JtIiwidG9hc3QiLCJ6IiwiZ2V0TWFuYWdlZFJlc3RhdXJhbnQiLCJ1cGRhdGVQcm9maWxlIiwiQnV0dG9uIiwiRGlhbG9nQ2xvc2UiLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIklucHV0IiwiTGFiZWwiLCJUZXh0YXJlYSIsInN0b3JlUHJvZmlsZVNjaGVtYSIsIm9iamVjdCIsIm5hbWUiLCJzdHJpbmciLCJtaW4iLCJkZXNjcmlwdGlvbiIsIm51bGxhYmxlIiwiU3RvcmVQcm9maWxlRGlhbG9nIiwiX3MiLCJxdWVyeUNsaWVudCIsImRhdGEiLCJtYW5hZ2VkUmVzdGF1cmFudCIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInN0YWxlVGltZSIsIkluZmluaXR5IiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJpc1N1Ym1pdHRpbmciLCJyZXNvbHZlciIsInpvZFJlc29sdmVyIiwidmFsdWVzIiwidXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSIsImNhY2hlZCIsImdldFF1ZXJ5RGF0YSIsInNldFF1ZXJ5RGF0YSIsIm11dGF0ZUFzeW5jIiwidXBkYXRlUHJvZmlsZUZuIiwibXV0YXRpb25GbiIsIm9uTXV0YXRlIiwicHJldml1c1Byb2ZpbGUiLCJvbkVycm9yIiwiXyIsIl9fIiwiY29udGV4dCIsImhhbmRsZVVwZGF0ZVByb2ZpbGUiLCJzdWNjZXNzIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInN0b3JlLXByb2ZpbGUtZGlhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xyXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcidcclxuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcclxuXHJcbmltcG9ydCB7XHJcbiAgZ2V0TWFuYWdlZFJlc3RhdXJhbnQsXHJcbiAgR2V0TWFuYWdlZFJlc3RhdXJhbnRSZXNwb25zZSxcclxufSBmcm9tICdAL2FwaS9nZXQtbWFuYWdlZC1yZXN0YXVyYW50J1xyXG5pbXBvcnQgeyB1cGRhdGVQcm9maWxlIH0gZnJvbSAnQC9hcGkvdXBkYXRlLXByb2ZpbGUnXHJcblxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL3VpL2J1dHRvbidcclxuaW1wb3J0IHtcclxuICBEaWFsb2dDbG9zZSxcclxuICBEaWFsb2dDb250ZW50LFxyXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxyXG4gIERpYWxvZ0Zvb3RlcixcclxuICBEaWFsb2dIZWFkZXIsXHJcbiAgRGlhbG9nVGl0bGUsXHJcbn0gZnJvbSAnLi91aS9kaWFsb2cnXHJcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi91aS9pbnB1dCdcclxuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICcuL3VpL2xhYmVsJ1xyXG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gJy4vdWkvdGV4dGFyZWEnXHJcblxyXG5jb25zdCBzdG9yZVByb2ZpbGVTY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgbmFtZTogei5zdHJpbmcoKS5taW4oMSksXHJcbiAgZGVzY3JpcHRpb246IHouc3RyaW5nKCkubnVsbGFibGUoKSxcclxufSlcclxuXHJcbnR5cGUgU3RvcmVQcm9maWxlU2NoZW1hID0gei5pbmZlcjx0eXBlb2Ygc3RvcmVQcm9maWxlU2NoZW1hPlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFN0b3JlUHJvZmlsZURpYWxvZygpIHtcclxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBtYW5hZ2VkUmVzdGF1cmFudCB9ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFsnbWFuYWdlZC1yZXN0YXVyYW50J10sXHJcbiAgICBxdWVyeUZuOiBnZXRNYW5hZ2VkUmVzdGF1cmFudCxcclxuICAgIHN0YWxlVGltZTogSW5maW5pdHksXHJcbiAgfSlcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICBmb3JtU3RhdGU6IHsgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08U3RvcmVQcm9maWxlU2NoZW1hPih7XHJcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoc3RvcmVQcm9maWxlU2NoZW1hKSxcclxuICAgIHZhbHVlczoge1xyXG4gICAgICBuYW1lOiBtYW5hZ2VkUmVzdGF1cmFudD8ubmFtZSA/PyAnJyxcclxuICAgICAgZGVzY3JpcHRpb246IG1hbmFnZWRSZXN0YXVyYW50Py5kZXNjcmlwdGlvbiA/PyAnJyxcclxuICAgIH0sXHJcbiAgfSlcclxuXHJcbiAgZnVuY3Rpb24gdXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSh7XHJcbiAgICBuYW1lLFxyXG4gICAgZGVzY3JpcHRpb24sXHJcbiAgfTogU3RvcmVQcm9maWxlU2NoZW1hKSB7XHJcbiAgICBjb25zdCBjYWNoZWQgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8R2V0TWFuYWdlZFJlc3RhdXJhbnRSZXNwb25zZT4oW1xyXG4gICAgICAnbWFuYWdlZC1yZXN0YXVyYW50JyxcclxuICAgIF0pXHJcblxyXG4gICAgaWYgKGNhY2hlZCkge1xyXG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8R2V0TWFuYWdlZFJlc3RhdXJhbnRSZXNwb25zZT4oXHJcbiAgICAgICAgWydtYW5hZ2VkLXJlc3RhdXJhbnQnXSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAuLi5jYWNoZWQsXHJcbiAgICAgICAgICBuYW1lLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb24sXHJcbiAgICAgICAgfSxcclxuICAgICAgKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHsgY2FjaGVkIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHVwZGF0ZVByb2ZpbGVGbiB9ID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogdXBkYXRlUHJvZmlsZSxcclxuICAgIG9uTXV0YXRlKHsgbmFtZSwgZGVzY3JpcHRpb24gfSkge1xyXG4gICAgICBjb25zdCB7IGNhY2hlZCB9ID0gdXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSh7IG5hbWUsIGRlc2NyaXB0aW9uIH0pXHJcblxyXG4gICAgICByZXR1cm4geyBwcmV2aXVzUHJvZmlsZTogY2FjaGVkIH1cclxuICAgIH0sXHJcbiAgICBvbkVycm9yKF8sIF9fLCBjb250ZXh0KSB7XHJcbiAgICAgIGlmIChjb250ZXh0Py5wcmV2aXVzUHJvZmlsZSkge1xyXG4gICAgICAgIHVwZGF0ZU1hbmFnZWRSZXN0YXVyYW50Q2FjaGUoY29udGV4dC5wcmV2aXVzUHJvZmlsZSlcclxuICAgICAgfVxyXG4gICAgfSxcclxuICB9KVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVVcGRhdGVQcm9maWxlKGRhdGE6IFN0b3JlUHJvZmlsZVNjaGVtYSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdXBkYXRlUHJvZmlsZUZuKHtcclxuICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB0b2FzdC5zdWNjZXNzKCdQZXJmaWwgYXR1YWxpemFkbyBjb20gc3VjZXNzbycpXHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgdG9hc3QuZXJyb3IoJ0ZhbGhhIGFvIGF0dWFsaXphciBvIHBlcmZpbCwgdGVudGUgbm92YW1lbnRlIScpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgIDxEaWFsb2dIZWFkZXI+XHJcbiAgICAgICAgPERpYWxvZ1RpdGxlPlBlcmZpbCBkYSBsb2phPC9EaWFsb2dUaXRsZT5cclxuICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+XHJcbiAgICAgICAgICBBdHVhbGl6ZSBhcyBpbmZvcm1hw6fDtWVzIGRvIHNldSBlc3RhYmVsZWNpbWVudG8gdmlzw612ZWlzIGFvIHNldSBjbGllbnRlXHJcbiAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cclxuICAgICAgPC9EaWFsb2dIZWFkZXI+XHJcblxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KGhhbmRsZVVwZGF0ZVByb2ZpbGUpfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBweS00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCIgaHRtbEZvcj1cIm5hbWVcIj5cclxuICAgICAgICAgICAgICBOb21lXHJcbiAgICAgICAgICAgIDwvTGFiZWw+XHJcbiAgICAgICAgICAgIDxJbnB1dCBjbGFzc05hbWU9XCJjb2wtc3Bhbi0zXCIgaWQ9XCJuYW1lXCIgey4uLnJlZ2lzdGVyKCduYW1lJyl9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPExhYmVsIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIiBodG1sRm9yPVwiZGVzY3JpcHRpb25cIj5cclxuICAgICAgICAgICAgICBEZXNjcmnDp8Ojb1xyXG4gICAgICAgICAgICA8L0xhYmVsPlxyXG4gICAgICAgICAgICA8VGV4dGFyZWFcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb2wtc3Bhbi0zXCJcclxuICAgICAgICAgICAgICBpZD1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2Rlc2NyaXB0aW9uJyl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxyXG4gICAgICAgICAgPERpYWxvZ0Nsb3NlIGFzQ2hpbGQ+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgdHlwZT1cImJ1dHRvblwiPlxyXG4gICAgICAgICAgICAgIENhbmNlbGFyXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9EaWFsb2dDbG9zZT5cclxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJzdWNjZXNzXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XHJcbiAgICAgICAgICAgIFNhbHZhclxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvRGlhbG9nQ29udGVudD5cclxuICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BY2VyIE5pdHJvIDUvRGVza3RvcC9yb2NrZXRzZWF0L2lnbml0ZS9yZWFjdC9yZWFjdC00L3Bpenphc2hvcC13ZWIvc3JjL2NvbXBvbmVudHMvc3RvcmUtcHJvZmlsZS1kaWFsb2cudHN4In0=