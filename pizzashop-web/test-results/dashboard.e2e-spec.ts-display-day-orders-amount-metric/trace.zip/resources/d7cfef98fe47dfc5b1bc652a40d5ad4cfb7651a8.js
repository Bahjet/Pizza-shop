import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { Button } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
export function OrderTableSkeleton() {
  return Array.from({ length: 10 }).map((_, i) => {
    return /* @__PURE__ */ jsxDEV(TableRow, { children: [
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Button, { disabled: true, variant: "outline", size: "xs", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
          lineNumber: 13,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
          lineNumber: 14,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 12,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[172px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 18,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[148px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 21,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[110px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 24,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[200px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[64px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[92px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 33,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[92px]" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, i, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this);
  });
}
_c = OrderTableSkeleton;
var _c;
$RefreshReg$(_c, "OrderTableSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVk7QUFaWiwyQkFBdUI7QUFBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFckMsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRTdCLGdCQUFTQyxxQkFBcUI7QUFDbkMsU0FBT0MsTUFBTUMsS0FBSyxFQUFFQyxRQUFRLEdBQUcsQ0FBQyxFQUFFQyxJQUFJLENBQUNDLEdBQUdDLE1BQU07QUFDOUMsV0FDRSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsYUFDQyxpQ0FBQyxVQUFPLFVBQVEsTUFBQyxTQUFRLFdBQVUsTUFBSyxNQUN0QztBQUFBLCtCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDM0IsdUJBQUMsVUFBSyxXQUFVLFdBQVUsa0NBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBM0JhQSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxFQUVKLENBQUM7QUFDSDtBQUFDQyxLQWxDZVA7QUFBa0IsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlNrZWxldG9uIiwiVGFibGVDZWxsIiwiVGFibGVSb3ciLCJPcmRlclRhYmxlU2tlbGV0b24iLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJtYXAiLCJfIiwiaSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItdGFibGUtc2tlbGV0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuXHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXHJcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xyXG5pbXBvcnQgeyBUYWJsZUNlbGwsIFRhYmxlUm93IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3RhYmxlJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyVGFibGVTa2VsZXRvbigpIHtcclxuICByZXR1cm4gQXJyYXkuZnJvbSh7IGxlbmd0aDogMTAgfSkubWFwKChfLCBpKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8VGFibGVSb3cga2V5PXtpfT5cclxuICAgICAgICA8VGFibGVDZWxsPlxyXG4gICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZCB2YXJpYW50PVwib3V0bGluZVwiIHNpemU9XCJ4c1wiPlxyXG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RGV0YWxoZXMgZG8gcGVkaWRvPC9zcGFuPlxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgPFRhYmxlQ2VsbD5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bMTcycHhdXCIgLz5cclxuICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICA8VGFibGVDZWxsPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVsxNDhweF1cIiAvPlxyXG4gICAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgICAgIDxUYWJsZUNlbGw+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzExMHB4XVwiIC8+XHJcbiAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgPFRhYmxlQ2VsbD5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bMjAwcHhdXCIgLz5cclxuICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICA8VGFibGVDZWxsPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVs2NHB4XVwiIC8+XHJcbiAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgPFRhYmxlQ2VsbD5cclxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bOTJweF1cIiAvPlxyXG4gICAgICAgIDwvVGFibGVDZWxsPlxyXG4gICAgICAgIDxUYWJsZUNlbGw+XHJcbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzkycHhdXCIgLz5cclxuICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgPC9UYWJsZVJvdz5cclxuICAgIClcclxuICB9KVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9wYWdlcy9hcHAvb3JkZXJzL29yZGVyLXRhYmxlLXNrZWxldG9uLnRzeCJ9