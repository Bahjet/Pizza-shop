import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/day-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { Utensils } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { getDayOrdersAmount } from "/src/api/get-day-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function DayOrdersAmountCard() {
  _s();
  const { data: dayOrdersAmount } = useQuery({
    queryFn: getDayOrdersAmount,
    queryKey: ["metrics", "day-orders-amount"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Pedidos (dia)" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Utensils, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: dayOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: dayOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 24,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: dayOrdersAmount.diffFromYesterday >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
          lineNumber: 30,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
          lineNumber: 37,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
        lineNumber: 27,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 46,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(DayOrdersAmountCard, "X4ooPoWX1BlcuKkrK9Waaxl5Cfg=", false, function() {
  return [useQuery];
});
_c = DayOrdersAmountCard;
var _c;
$RefreshReg$(_c, "DayOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/day-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBV1EsVUFYUjsyQkFqQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyxzQkFBc0I7QUFBQUMsS0FBQTtBQUNwQyxRQUFNLEVBQUVDLE1BQU1DLGdCQUFnQixJQUFJQyxTQUFTO0FBQUEsSUFDekNDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLG1CQUFtQjtBQUFBLEVBQzNDLENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQ0M7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUEwQiw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLE1BQzVELHVCQUFDLFlBQVMsV0FBVSxtQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLFNBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsZUFBWSxXQUFVLGFBQ3BCSCw0QkFDQyxtQ0FDRTtBQUFBLDZCQUFDLFVBQUssV0FBVSxxQ0FDYkEsMEJBQWdCSSxPQUFPQyxlQUFlLE9BQU8sS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQ1ZMLDBCQUFnQk0scUJBQXFCLElBQ3BDLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDBDQUNiTjtBQUFBQSwwQkFBZ0JNO0FBQUFBLFVBQWtCO0FBQUEsYUFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUk7QUFBQSxXQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxJQUVBLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLG9DQUNiTjtBQUFBQSwwQkFBZ0JNO0FBQUFBLFVBQWtCO0FBQUEsYUFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUk7QUFBQSxXQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBLElBRUEsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQXpCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQ0E7QUFFSjtBQUFDUixHQTFDZUQscUJBQW1CO0FBQUEsVUFDQ0ksUUFBUTtBQUFBO0FBQUFNLEtBRDVCVjtBQUFtQixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVXRlbnNpbHMiLCJnZXREYXlPcmRlcnNBbW91bnQiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiTWV0cmljQ2FyZFNrZWxldG9uIiwiRGF5T3JkZXJzQW1vdW50Q2FyZCIsIl9zIiwiZGF0YSIsImRheU9yZGVyc0Ftb3VudCIsInVzZVF1ZXJ5IiwicXVlcnlGbiIsInF1ZXJ5S2V5IiwiYW1vdW50IiwidG9Mb2NhbGVTdHJpbmciLCJkaWZmRnJvbVllc3RlcmRheSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGF5LW9yZGVycy1hbW91bnQtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IFV0ZW5zaWxzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5cclxuaW1wb3J0IHsgZ2V0RGF5T3JkZXJzQW1vdW50IH0gZnJvbSAnQC9hcGkvZ2V0LWRheS1vcmRlcnMtYW1vdW50J1xyXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXHJcblxyXG5pbXBvcnQgeyBNZXRyaWNDYXJkU2tlbGV0b24gfSBmcm9tICcuL21ldHJpYy1jYXJkLXNrZWxldG9uJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERheU9yZGVyc0Ftb3VudENhcmQoKSB7XHJcbiAgY29uc3QgeyBkYXRhOiBkYXlPcmRlcnNBbW91bnQgfSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5Rm46IGdldERheU9yZGVyc0Ftb3VudCxcclxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnZGF5LW9yZGVycy1hbW91bnQnXSxcclxuICB9KVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPENhcmQ+XHJcbiAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cImZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0wIHBiLTJcIj5cclxuICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+UGVkaWRvcyAoZGlhKTwvQ2FyZFRpdGxlPlxyXG4gICAgICAgIDxVdGVuc2lscyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XHJcbiAgICAgIDwvQ2FyZEhlYWRlcj5cclxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgIHtkYXlPcmRlcnNBbW91bnQgPyAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICB7ZGF5T3JkZXJzQW1vdW50LmFtb3VudC50b0xvY2FsZVN0cmluZygncHQtQlInKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxyXG4gICAgICAgICAgICAgIHtkYXlPcmRlcnNBbW91bnQuZGlmZkZyb21ZZXN0ZXJkYXkgPj0gMCA/IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC01MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2RheU9yZGVyc0Ftb3VudC5kaWZmRnJvbVllc3RlcmRheX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxyXG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYSBvbnRlbVxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2RheU9yZGVyc0Ftb3VudC5kaWZmRnJvbVllc3RlcmRheX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxyXG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYSBvbnRlbVxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgPC9DYXJkPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9kYXktb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJ9