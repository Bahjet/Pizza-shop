import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-YB7XOHEW.js?v=12cb1194";
import "/node_modules/.vite/deps/chunk-TIUEEL27.js?v=12cb1194";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
