import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=12cb1194";
export const getProfileMock = http.get(
  "/me",
  () => {
    return HttpResponse.json({
      id: "custom-user-id",
      name: "John Doe",
      email: "johndoe@example.com",
      phone: "8123712723",
      role: "manager",
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: null
    });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1wcm9maWxlLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xyXG5cclxuaW1wb3J0IHsgR2V0UHJvZmlsZVJlc3BvbnNlIH0gZnJvbSAnLi4vZ2V0LXByb2ZpbGUnXHJcblxyXG5leHBvcnQgY29uc3QgZ2V0UHJvZmlsZU1vY2sgPSBodHRwLmdldDxuZXZlciwgbmV2ZXIsIEdldFByb2ZpbGVSZXNwb25zZT4oXHJcbiAgJy9tZScsXHJcbiAgKCkgPT4ge1xyXG4gICAgcmV0dXJuIEh0dHBSZXNwb25zZS5qc29uKHtcclxuICAgICAgaWQ6ICdjdXN0b20tdXNlci1pZCcsXHJcbiAgICAgIG5hbWU6ICdKb2huIERvZScsXHJcbiAgICAgIGVtYWlsOiAnam9obmRvZUBleGFtcGxlLmNvbScsXHJcbiAgICAgIHBob25lOiAnODEyMzcxMjcyMycsXHJcbiAgICAgIHJvbGU6ICdtYW5hZ2VyJyxcclxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICB1cGRhdGVkQXQ6IG51bGwsXHJcbiAgICB9KVxyXG4gIH0sXHJcbilcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLE1BQU0sb0JBQW9CO0FBSTVCLGFBQU0saUJBQWlCLEtBQUs7QUFBQSxFQUNqQztBQUFBLEVBQ0EsTUFBTTtBQUNKLFdBQU8sYUFBYSxLQUFLO0FBQUEsTUFDdkIsSUFBSTtBQUFBLE1BQ0osTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLE1BQ1AsTUFBTTtBQUFBLE1BQ04sV0FBVyxvQkFBSSxLQUFLO0FBQUEsTUFDcEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUFBLEVBQ0g7QUFDRjsiLCJuYW1lcyI6W119