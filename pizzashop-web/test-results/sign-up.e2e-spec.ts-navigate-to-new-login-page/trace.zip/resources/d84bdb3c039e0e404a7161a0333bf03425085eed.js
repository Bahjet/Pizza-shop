import.meta.env = {"VITE_API_URL": "/", "VITE_ENABLE_API_DELAY": "false", "BASE_URL": "/", "MODE": "test", "DEV": true, "PROD": false, "SSR": false};import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
const envSchema = z.object({
  MODE: z.enum(["production", "development", "test"]),
  VITE_API_URL: z.string(),
  VITE_ENABLE_API_DELAY: z.string().transform((value) => value === "true")
});
export const env = envSchema.parse(import.meta.env);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVudi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6IH0gZnJvbSAnem9kJ1xyXG5cclxuY29uc3QgZW52U2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIE1PREU6IHouZW51bShbJ3Byb2R1Y3Rpb24nLCAnZGV2ZWxvcG1lbnQnLCAndGVzdCddKSxcclxuICBWSVRFX0FQSV9VUkw6IHouc3RyaW5nKCksXHJcbiAgVklURV9FTkFCTEVfQVBJX0RFTEFZOiB6LnN0cmluZygpLnRyYW5zZm9ybSgodmFsdWUpID0+IHZhbHVlID09PSAndHJ1ZScpLFxyXG59KVxyXG5cclxuZXhwb3J0IGNvbnN0IGVudiA9IGVudlNjaGVtYS5wYXJzZShpbXBvcnQubWV0YS5lbnYpXHJcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTO0FBRWxCLE1BQU0sWUFBWSxFQUFFLE9BQU87QUFBQSxFQUN6QixNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsZUFBZSxNQUFNLENBQUM7QUFBQSxFQUNsRCxjQUFjLEVBQUUsT0FBTztBQUFBLEVBQ3ZCLHVCQUF1QixFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsVUFBVSxVQUFVLE1BQU07QUFDekUsQ0FBQztBQUVNLGFBQU0sTUFBTSxVQUFVLE1BQU0sWUFBWSxHQUFHOyIsIm5hbWVzIjpbXX0=