import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=12cb1194";
export const getOrderDetailsMock = http.get("/orders/:orderId", ({ params }) => {
  return HttpResponse.json({
    id: params.orderId,
    customer: {
      name: "John Doe",
      email: "johndoe@example.com",
      phone: "123124125115"
    },
    status: "pending",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    totalInCents: 5e3,
    orderItems: [
      {
        id: "order-item-1",
        priceInCents: 1e3,
        product: { name: "Pizza Pepperoni" },
        quantity: 1
      },
      {
        id: "order-item-2",
        priceInCents: 2e3,
        product: { name: "Pizza Marguerita" },
        quantity: 2
      }
    ]
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1vcmRlci1kZXRhaWxzLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xyXG5cclxuaW1wb3J0IHtcclxuICBHZXRPcmRlckRldGFpbHNQYXJhbXMsXHJcbiAgR2V0T3JkZXJEZXRhaWxzUmVzcG9uc2UsXHJcbn0gZnJvbSAnLi4vZ2V0LW9yZGVyLWRldGFpbHMnXHJcblxyXG5leHBvcnQgY29uc3QgZ2V0T3JkZXJEZXRhaWxzTW9jayA9IGh0dHAuZ2V0PFxyXG4gIEdldE9yZGVyRGV0YWlsc1BhcmFtcyxcclxuICBuZXZlcixcclxuICBHZXRPcmRlckRldGFpbHNSZXNwb25zZVxyXG4+KCcvb3JkZXJzLzpvcmRlcklkJywgKHsgcGFyYW1zIH0pID0+IHtcclxuICByZXR1cm4gSHR0cFJlc3BvbnNlLmpzb24oe1xyXG4gICAgaWQ6IHBhcmFtcy5vcmRlcklkLFxyXG4gICAgY3VzdG9tZXI6IHtcclxuICAgICAgbmFtZTogJ0pvaG4gRG9lJyxcclxuICAgICAgZW1haWw6ICdqb2huZG9lQGV4YW1wbGUuY29tJyxcclxuICAgICAgcGhvbmU6ICcxMjMxMjQxMjUxMTUnLFxyXG4gICAgfSxcclxuICAgIHN0YXR1czogJ3BlbmRpbmcnLFxyXG4gICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICB0b3RhbEluQ2VudHM6IDUwMDAsXHJcbiAgICBvcmRlckl0ZW1zOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogJ29yZGVyLWl0ZW0tMScsXHJcbiAgICAgICAgcHJpY2VJbkNlbnRzOiAxMDAwLFxyXG4gICAgICAgIHByb2R1Y3Q6IHsgbmFtZTogJ1BpenphIFBlcHBlcm9uaScgfSxcclxuICAgICAgICBxdWFudGl0eTogMSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGlkOiAnb3JkZXItaXRlbS0yJyxcclxuICAgICAgICBwcmljZUluQ2VudHM6IDIwMDAsXHJcbiAgICAgICAgcHJvZHVjdDogeyBuYW1lOiAnUGl6emEgTWFyZ3Vlcml0YScgfSxcclxuICAgICAgICBxdWFudGl0eTogMixcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgfSlcclxufSlcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLE1BQU0sb0JBQW9CO0FBTzVCLGFBQU0sc0JBQXNCLEtBQUssSUFJdEMsb0JBQW9CLENBQUMsRUFBRSxPQUFPLE1BQU07QUFDcEMsU0FBTyxhQUFhLEtBQUs7QUFBQSxJQUN2QixJQUFJLE9BQU87QUFBQSxJQUNYLFVBQVU7QUFBQSxNQUNSLE1BQU07QUFBQSxNQUNOLE9BQU87QUFBQSxNQUNQLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxRQUFRO0FBQUEsSUFDUixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsY0FBYztBQUFBLElBQ2QsWUFBWTtBQUFBLE1BQ1Y7QUFBQSxRQUNFLElBQUk7QUFBQSxRQUNKLGNBQWM7QUFBQSxRQUNkLFNBQVMsRUFBRSxNQUFNLGtCQUFrQjtBQUFBLFFBQ25DLFVBQVU7QUFBQSxNQUNaO0FBQUEsTUFDQTtBQUFBLFFBQ0UsSUFBSTtBQUFBLFFBQ0osY0FBYztBQUFBLFFBQ2QsU0FBUyxFQUFFLE1BQU0sbUJBQW1CO0FBQUEsUUFDcEMsVUFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0gsQ0FBQzsiLCJuYW1lcyI6W119