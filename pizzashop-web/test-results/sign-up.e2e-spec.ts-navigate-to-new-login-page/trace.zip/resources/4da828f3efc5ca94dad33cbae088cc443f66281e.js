import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { getMonthCanceledOrdersAmount } from "/src/api/get-month-canceled-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthCanceledOrdersAmountCard() {
  _s();
  const { data: monthCanceledOrdersAmount } = useQuery({
    queryFn: getMonthCanceledOrdersAmount,
    queryKey: ["metrics", "month-canceled-orders-amount"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Cancelametos (mês)" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthCanceledOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: monthCanceledOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: monthCanceledOrdersAmount.diffFromLastMonth < 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 32,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 31,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          "+",
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 39,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 38,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(MonthCanceledOrdersAmountCard, "8+4OTDJzpazOHlKic+kKfdz2IPM=", false, function() {
  return [useQuery];
});
_c = MonthCanceledOrdersAmountCard;
var _c;
$RefreshReg$(_c, "MonthCanceledOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBYVEsVUFiUjsyQkFqQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0Esa0JBQWtCO0FBRTNCLFNBQVNDLG9DQUFvQztBQUM3QyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyxnQ0FBZ0M7QUFBQUMsS0FBQTtBQUM5QyxRQUFNLEVBQUVDLE1BQU1DLDBCQUEwQixJQUFJQyxTQUFTO0FBQUEsSUFDbkRDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLDhCQUE4QjtBQUFBLEVBQ3RELENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQ0M7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUEwQixrQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLFdBQVUsbUNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGVBQVksV0FBVSxhQUNwQkgsc0NBQ0MsbUNBQ0U7QUFBQSw2QkFBQyxVQUFLLFdBQVUscUNBQ2JBLG9DQUEwQkksT0FBT0MsZUFBZSxPQUFPLEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUNWTCxvQ0FBMEJNLG9CQUFvQixJQUM3QyxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSwwQ0FDYk47QUFBQUEsb0NBQTBCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFJO0FBQUEsV0FIZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLFVBQy9DTiwwQkFBMEJNO0FBQUFBLFVBQWtCO0FBQUEsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUk7QUFBQSxXQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBLElBRUEsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQXpCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLE9BbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQ0E7QUFFSjtBQUFDUixHQTVDZUQsK0JBQTZCO0FBQUEsVUFDQ0ksUUFBUTtBQUFBO0FBQUFNLEtBRHRDVjtBQUE2QixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRG9sbGFyU2lnbiIsImdldE1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiTWV0cmljQ2FyZFNrZWxldG9uIiwiTW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudENhcmQiLCJfcyIsImRhdGEiLCJtb250aENhbmNlbGVkT3JkZXJzQW1vdW50IiwidXNlUXVlcnkiLCJxdWVyeUZuIiwicXVlcnlLZXkiLCJhbW91bnQiLCJ0b0xvY2FsZVN0cmluZyIsImRpZmZGcm9tTGFzdE1vbnRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJtb250aC1jYW5jZWxlZC1vcmRlcnMtYW1vdW50LWNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5cclxuaW1wb3J0IHsgZ2V0TW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCB9IGZyb20gJ0AvYXBpL2dldC1tb250aC1jYW5jZWxlZC1vcmRlcnMtYW1vdW50J1xyXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXHJcblxyXG5pbXBvcnQgeyBNZXRyaWNDYXJkU2tlbGV0b24gfSBmcm9tICcuL21ldHJpYy1jYXJkLXNrZWxldG9uJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnRDYXJkKCkge1xyXG4gIGNvbnN0IHsgZGF0YTogbW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCB9ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlGbjogZ2V0TW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCxcclxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnbW9udGgtY2FuY2VsZWQtb3JkZXJzLWFtb3VudCddLFxyXG4gIH0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q2FyZD5cclxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTAgcGItMlwiPlxyXG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgIENhbmNlbGFtZXRvcyAobcOqcylcclxuICAgICAgICA8L0NhcmRUaXRsZT5cclxuICAgICAgICA8RG9sbGFyU2lnbiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XHJcbiAgICAgIDwvQ2FyZEhlYWRlcj5cclxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgIHttb250aENhbmNlbGVkT3JkZXJzQW1vdW50ID8gKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAge21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQuYW1vdW50LnRvTG9jYWxlU3RyaW5nKCdwdC1CUicpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XHJcbiAgICAgICAgICAgICAge21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGggPCAwID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudC5kaWZmRnJvbUxhc3RNb250aH0lXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxyXG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBwYXNzYWRvXHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMCBkYXJrOnRleHQtcm9zZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAre21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGh9JVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cclxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGFvIG3DqnMgcGFzc2Fkb1xyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cclxuICAgICAgICApfVxyXG4gICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgPC9DYXJkPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9tb250aC1jYW5jZWxlZC1vcmRlcnMtYW1vdW50LWNhcmQudHN4In0=