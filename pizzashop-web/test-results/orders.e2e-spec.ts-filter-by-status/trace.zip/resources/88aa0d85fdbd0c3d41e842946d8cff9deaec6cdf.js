import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/orders.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=12cb1194";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
import { getOrders } from "/src/api/get-orders.ts";
import { Pagination } from "/src/components/pagination.tsx";
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import { OrderTableFilters } from "/src/pages/app/orders/order-table-filters.tsx";
import { OrderTableRow } from "/src/pages/app/orders/order-table-row.tsx?t=1713894108050";
import { OrderTableSkeleton } from "/src/pages/app/orders/order-table-skeleton.tsx";
export function Orders() {
  _s();
  const [searchParams, setSearchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const customerName = searchParams.get("customerName");
  const status = searchParams.get("status");
  const pageIndex = z.coerce.number().transform((page) => page - 1).parse(searchParams.get("page") ?? "1");
  const { data: result, isLoading: isLoadingOrders } = useQuery({
    queryKey: ["orders", pageIndex, orderId, customerName, status],
    queryFn: () => getOrders({
      pageIndex,
      orderId,
      customerName,
      status: status === "all" ? null : status
    })
  });
  function handlePaginate(pageIndex2) {
    setSearchParams((state) => {
      state.set("page", (pageIndex2 + 1).toString());
      return state;
    });
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Pedidos" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold tracking-tight", children: "Pedidos" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2.5", children: [
        /* @__PURE__ */ jsxDEV(OrderTableFilters, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
          lineNumber: 57,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-md border", children: /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[64px]" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 63,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Identificador" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 64,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[180px]", children: "Realizado há" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 65,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Status" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 66,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { children: "Cliente" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 67,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[140px]", children: "Total do pedido" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 68,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[164px]" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 69,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableHead, { className: "w-[132px]" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 70,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
            lineNumber: 62,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
            lineNumber: 61,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableBody, { children: isLoadingOrders ? /* @__PURE__ */ jsxDEV(OrderTableSkeleton, {}, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
            lineNumber: 75,
            columnNumber: 17
          }, this) : result?.orders.map((order) => {
            return /* @__PURE__ */ jsxDEV(OrderTableRow, { order }, order.orderId, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
              lineNumber: 78,
              columnNumber: 26
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
            lineNumber: 73,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
          lineNumber: 60,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        result && /* @__PURE__ */ jsxDEV(
          Pagination,
          {
            onPageChange: handlePaginate,
            pageIndex: result.meta.pageIndex,
            totalCount: result.meta.totalCount,
            perPage: result.meta.perPage
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
            lineNumber: 85,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
        lineNumber: 56,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(Orders, "nWfvfAtxOuif4HYB1Wmf0wmtOQ8=", false, function() {
  return [useSearchParams, useQuery];
});
_c = Orders;
var _c;
$RefreshReg$(_c, "Orders");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/orders.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURJLG1CQUNFLGNBREY7MkJBbkRKO0FBQWlCLE1BQVEscUJBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2hELFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFNBQVM7QUFFbEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDBCQUEwQjtBQUU1QixnQkFBU0MsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJZixnQkFBZ0I7QUFFeEQsUUFBTWdCLFVBQVVGLGFBQWFHLElBQUksU0FBUztBQUMxQyxRQUFNQyxlQUFlSixhQUFhRyxJQUFJLGNBQWM7QUFDcEQsUUFBTUUsU0FBU0wsYUFBYUcsSUFBSSxRQUFRO0FBRXhDLFFBQU1HLFlBQVluQixFQUFFb0IsT0FDakJDLE9BQU8sRUFDUEMsVUFBVSxDQUFDQyxTQUFTQSxPQUFPLENBQUMsRUFDNUJDLE1BQU1YLGFBQWFHLElBQUksTUFBTSxLQUFLLEdBQUc7QUFFeEMsUUFBTSxFQUFFUyxNQUFNQyxRQUFRQyxXQUFXQyxnQkFBZ0IsSUFBSUMsU0FBUztBQUFBLElBQzVEQyxVQUFVLENBQUMsVUFBVVgsV0FBV0osU0FBU0UsY0FBY0MsTUFBTTtBQUFBLElBQzdEYSxTQUFTQSxNQUNQOUIsVUFBVTtBQUFBLE1BQ1JrQjtBQUFBQSxNQUNBSjtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBQyxRQUFRQSxXQUFXLFFBQVEsT0FBT0E7QUFBQUEsSUFDcEMsQ0FBQztBQUFBLEVBQ0wsQ0FBQztBQUVELFdBQVNjLGVBQWViLFlBQW1CO0FBQ3pDTCxvQkFBZ0IsQ0FBQ21CLFVBQVU7QUFDekJBLFlBQU1DLElBQUksU0FBU2YsYUFBWSxHQUFHZ0IsU0FBUyxDQUFDO0FBRTVDLGFBQU9GO0FBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLGFBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QjtBQUFBLElBQ3ZCLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsdUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUN6RCx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUVsQix1QkFBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsU0FDQztBQUFBLGlDQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLG1DQUFDLGFBQVUsV0FBVSxjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQ2hDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLDZCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLDRCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLGFBQVUsV0FBVSxhQUFZLHNCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLGFBQVUsdUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQSxZQUNsQix1QkFBQyxhQUFVLFdBQVUsYUFBWSwrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Q7QUFBQSxZQUNoRCx1QkFBQyxhQUFVLFdBQVUsZUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxhQUFVLFdBQVUsZUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsYUFDRUwsNEJBQ0MsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUIsSUFFbkJGLFFBQVFVLE9BQU9DLElBQUksQ0FBQ0MsVUFBVTtBQUM1QixtQkFBTyx1QkFBQyxpQkFBa0MsU0FBZkEsTUFBTXZCLFNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsVUFDekQsQ0FBQyxLQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUNDVyxVQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxjQUFjTTtBQUFBQSxZQUNkLFdBQVdOLE9BQU9hLEtBQUtwQjtBQUFBQSxZQUN2QixZQUFZTyxPQUFPYSxLQUFLQztBQUFBQSxZQUN4QixTQUFTZCxPQUFPYSxLQUFLRTtBQUFBQTtBQUFBQSxVQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJK0I7QUFBQSxXQWpDbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9DQTtBQUFBLFNBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxPQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMENBO0FBRUo7QUFBQzdCLEdBNUVlRCxRQUFNO0FBQUEsVUFDb0JaLGlCQVdhOEIsUUFBUTtBQUFBO0FBQUFhLEtBWi9DL0I7QUFBTSxJQUFBK0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlbG1ldCIsInVzZVNlYXJjaFBhcmFtcyIsInoiLCJnZXRPcmRlcnMiLCJQYWdpbmF0aW9uIiwiVGFibGUiLCJUYWJsZUJvZHkiLCJUYWJsZUhlYWQiLCJUYWJsZUhlYWRlciIsIlRhYmxlUm93IiwiT3JkZXJUYWJsZUZpbHRlcnMiLCJPcmRlclRhYmxlUm93IiwiT3JkZXJUYWJsZVNrZWxldG9uIiwiT3JkZXJzIiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJzZXRTZWFyY2hQYXJhbXMiLCJvcmRlcklkIiwiZ2V0IiwiY3VzdG9tZXJOYW1lIiwic3RhdHVzIiwicGFnZUluZGV4IiwiY29lcmNlIiwibnVtYmVyIiwidHJhbnNmb3JtIiwicGFnZSIsInBhcnNlIiwiZGF0YSIsInJlc3VsdCIsImlzTG9hZGluZyIsImlzTG9hZGluZ09yZGVycyIsInVzZVF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiaGFuZGxlUGFnaW5hdGUiLCJzdGF0ZSIsInNldCIsInRvU3RyaW5nIiwib3JkZXJzIiwibWFwIiwib3JkZXIiLCJtZXRhIiwidG90YWxDb3VudCIsInBlclBhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVycy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldC1hc3luYydcclxuaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcclxuXHJcbmltcG9ydCB7IGdldE9yZGVycyB9IGZyb20gJ0AvYXBpL2dldC1vcmRlcnMnXHJcbmltcG9ydCB7IFBhZ2luYXRpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvcGFnaW5hdGlvbidcclxuaW1wb3J0IHtcclxuICBUYWJsZSxcclxuICBUYWJsZUJvZHksXHJcbiAgVGFibGVIZWFkLFxyXG4gIFRhYmxlSGVhZGVyLFxyXG4gIFRhYmxlUm93LFxyXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcclxuXHJcbmltcG9ydCB7IE9yZGVyVGFibGVGaWx0ZXJzIH0gZnJvbSAnLi9vcmRlci10YWJsZS1maWx0ZXJzJ1xyXG5pbXBvcnQgeyBPcmRlclRhYmxlUm93IH0gZnJvbSAnLi9vcmRlci10YWJsZS1yb3cnXHJcbmltcG9ydCB7IE9yZGVyVGFibGVTa2VsZXRvbiB9IGZyb20gJy4vb3JkZXItdGFibGUtc2tlbGV0b24nXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJzKCkge1xyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxyXG5cclxuICBjb25zdCBvcmRlcklkID0gc2VhcmNoUGFyYW1zLmdldCgnb3JkZXJJZCcpXHJcbiAgY29uc3QgY3VzdG9tZXJOYW1lID0gc2VhcmNoUGFyYW1zLmdldCgnY3VzdG9tZXJOYW1lJylcclxuICBjb25zdCBzdGF0dXMgPSBzZWFyY2hQYXJhbXMuZ2V0KCdzdGF0dXMnKVxyXG5cclxuICBjb25zdCBwYWdlSW5kZXggPSB6LmNvZXJjZVxyXG4gICAgLm51bWJlcigpXHJcbiAgICAudHJhbnNmb3JtKChwYWdlKSA9PiBwYWdlIC0gMSlcclxuICAgIC5wYXJzZShzZWFyY2hQYXJhbXMuZ2V0KCdwYWdlJykgPz8gJzEnKVxyXG5cclxuICBjb25zdCB7IGRhdGE6IHJlc3VsdCwgaXNMb2FkaW5nOiBpc0xvYWRpbmdPcmRlcnMgfSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5S2V5OiBbJ29yZGVycycsIHBhZ2VJbmRleCwgb3JkZXJJZCwgY3VzdG9tZXJOYW1lLCBzdGF0dXNdLFxyXG4gICAgcXVlcnlGbjogKCkgPT5cclxuICAgICAgZ2V0T3JkZXJzKHtcclxuICAgICAgICBwYWdlSW5kZXgsXHJcbiAgICAgICAgb3JkZXJJZCxcclxuICAgICAgICBjdXN0b21lck5hbWUsXHJcbiAgICAgICAgc3RhdHVzOiBzdGF0dXMgPT09ICdhbGwnID8gbnVsbCA6IHN0YXR1cyxcclxuICAgICAgfSksXHJcbiAgfSlcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlUGFnaW5hdGUocGFnZUluZGV4OiBudW1iZXIpIHtcclxuICAgIHNldFNlYXJjaFBhcmFtcygoc3RhdGUpID0+IHtcclxuICAgICAgc3RhdGUuc2V0KCdwYWdlJywgKHBhZ2VJbmRleCArIDEpLnRvU3RyaW5nKCkpXHJcblxyXG4gICAgICByZXR1cm4gc3RhdGVcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPEhlbG1ldCB0aXRsZT1cIlBlZGlkb3NcIiAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+UGVkaWRvczwvaDE+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIuNVwiPlxyXG4gICAgICAgICAgPE9yZGVyVGFibGVGaWx0ZXJzIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlclwiPlxyXG4gICAgICAgICAgICA8VGFibGU+XHJcbiAgICAgICAgICAgICAgPFRhYmxlSGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlUm93PlxyXG4gICAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInctWzY0cHhdXCI+PC9UYWJsZUhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTQwcHhdXCI+SWRlbnRpZmljYWRvcjwvVGFibGVIZWFkPlxyXG4gICAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInctWzE4MHB4XVwiPlJlYWxpemFkbyBow6E8L1RhYmxlSGVhZD5cclxuICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZCBjbGFzc05hbWU9XCJ3LVsxNDBweF1cIj5TdGF0dXM8L1RhYmxlSGVhZD5cclxuICAgICAgICAgICAgICAgICAgPFRhYmxlSGVhZD5DbGllbnRlPC9UYWJsZUhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTQwcHhdXCI+VG90YWwgZG8gcGVkaWRvPC9UYWJsZUhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTY0cHhdXCI+PC9UYWJsZUhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidy1bMTMycHhdXCI+PC9UYWJsZUhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxyXG4gICAgICAgICAgICAgIDwvVGFibGVIZWFkZXI+XHJcbiAgICAgICAgICAgICAgPFRhYmxlQm9keT5cclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmdPcmRlcnMgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxPcmRlclRhYmxlU2tlbGV0b24gLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIHJlc3VsdD8ub3JkZXJzLm1hcCgob3JkZXIpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gPE9yZGVyVGFibGVSb3cga2V5PXtvcmRlci5vcmRlcklkfSBvcmRlcj17b3JkZXJ9IC8+XHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvVGFibGVCb2R5PlxyXG4gICAgICAgICAgICA8L1RhYmxlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7cmVzdWx0ICYmIChcclxuICAgICAgICAgICAgPFBhZ2luYXRpb25cclxuICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2luYXRlfVxyXG4gICAgICAgICAgICAgIHBhZ2VJbmRleD17cmVzdWx0Lm1ldGEucGFnZUluZGV4fVxyXG4gICAgICAgICAgICAgIHRvdGFsQ291bnQ9e3Jlc3VsdC5tZXRhLnRvdGFsQ291bnR9XHJcbiAgICAgICAgICAgICAgcGVyUGFnZT17cmVzdWx0Lm1ldGEucGVyUGFnZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9wYWdlcy9hcHAvb3JkZXJzL29yZGVycy50c3gifQ==