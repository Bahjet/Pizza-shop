import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-filters.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=12cb1194";
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { Controller, useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=12cb1194";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const orderFiltersSchema = z.object({
  orderId: z.string().optional(),
  customerName: z.string().optional(),
  status: z.string().optional()
});
export function OrderTableFilters() {
  _s();
  const [searchParams, setSearchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const customerName = searchParams.get("customerName");
  const status = searchParams.get("status");
  const { register, handleSubmit, control, reset } = useForm({
    resolver: zodResolver(orderFiltersSchema),
    defaultValues: {
      orderId: orderId ?? "",
      customerName: customerName ?? "",
      status: status ?? "all"
    }
  });
  function handleFitler({ orderId: orderId2, customerName: customerName2, status: status2 }) {
    setSearchParams((state) => {
      if (orderId2) {
        state.set("orderId", orderId2);
      } else {
        state.delete("orderId");
      }
      if (customerName2) {
        state.set("customerName", customerName2);
      } else {
        state.delete("customerName");
      }
      if (status2) {
        state.set("status", status2);
      } else {
        state.delete("status");
      }
      state.set("page", "1");
      return state;
    });
  }
  function handleClearFilters() {
    setSearchParams((state) => {
      state.delete("orderId");
      state.delete("customerName");
      state.delete("status");
      state.set("page", "1");
      return state;
    });
    reset({
      orderId: "",
      customerName: "",
      status: "all"
    });
  }
  return /* @__PURE__ */ jsxDEV(
    "form",
    {
      onSubmit: handleSubmit(handleFitler),
      className: "flex items-center gap-2",
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Filtros:" }, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 90,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "ID do pedido",
            className: "h-8 w-auto",
            ...register("orderId")
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 91,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Nome do cliente",
            className: "h-8 w-[320px]",
            ...register("customerName")
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 96,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Controller,
          {
            name: "status",
            control,
            render: ({ field: { name, onChange, value, disabled } }) => {
              return /* @__PURE__ */ jsxDEV(
                Select,
                {
                  defaultValue: "all",
                  name,
                  onValueChange: onChange,
                  value,
                  disabled,
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 w-[180px]", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 114,
                      columnNumber: 17
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 113,
                      columnNumber: 15
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "Todos status" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 117,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "pending", children: "Pendente" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 118,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "canceled", children: "Cancelado" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 119,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "processing", children: "Em preparo" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 120,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivering", children: "Em entrega" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 121,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivered", children: "Entregue" }, void 0, false, {
                        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 122,
                        columnNumber: 17
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 116,
                      columnNumber: 15
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                  lineNumber: 106,
                  columnNumber: 13
                },
                this
              );
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 101,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "secondary", size: "xs", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 130,
            columnNumber: 9
          }, this),
          "Filtrar resultados"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 129,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleClearFilters,
            type: "button",
            variant: "outline",
            size: "xs",
            children: [
              /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
                lineNumber: 140,
                columnNumber: 9
              }, this),
              "Remover filtros"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 134,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx",
      lineNumber: 86,
      columnNumber: 5
    },
    this
  );
}
_s(OrderTableFilters, "feHCo+4TPh8lpkrfrpltwU9U2Mo=", false, function() {
  return [useSearchParams, useForm];
});
_c = OrderTableFilters;
var _c;
$RefreshReg$(_c, "OrderTableFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/orders/order-table-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZNOzJCQXpGTjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsUUFBUUMsU0FBUztBQUMxQixTQUFTQyxZQUFZQyxlQUFlO0FBQ3BDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxTQUFTO0FBRWxCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxxQkFBcUJSLEVBQUVTLE9BQU87QUFBQSxFQUNsQ0MsU0FBU1YsRUFBRVcsT0FBTyxFQUFFQyxTQUFTO0FBQUEsRUFDN0JDLGNBQWNiLEVBQUVXLE9BQU8sRUFBRUMsU0FBUztBQUFBLEVBQ2xDRSxRQUFRZCxFQUFFVyxPQUFPLEVBQUVDLFNBQVM7QUFDOUIsQ0FBQztBQUlNLGdCQUFTRyxvQkFBb0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSW5CLGdCQUFnQjtBQUV4RCxRQUFNVyxVQUFVTyxhQUFhRSxJQUFJLFNBQVM7QUFDMUMsUUFBTU4sZUFBZUksYUFBYUUsSUFBSSxjQUFjO0FBQ3BELFFBQU1MLFNBQVNHLGFBQWFFLElBQUksUUFBUTtBQUV4QyxRQUFNLEVBQUVDLFVBQVVDLGNBQWNDLFNBQVNDLE1BQU0sSUFDN0N6QixRQUE0QjtBQUFBLElBQzFCMEIsVUFBVUMsWUFBWWpCLGtCQUFrQjtBQUFBLElBQ3hDa0IsZUFBZTtBQUFBLE1BQ2JoQixTQUFTQSxXQUFXO0FBQUEsTUFDcEJHLGNBQWNBLGdCQUFnQjtBQUFBLE1BQzlCQyxRQUFRQSxVQUFVO0FBQUEsSUFDcEI7QUFBQSxFQUNGLENBQUM7QUFFSCxXQUFTYSxhQUFhLEVBQUVqQixtQkFBU0csNkJBQWNDLGdCQUEyQixHQUFHO0FBQzNFSSxvQkFBZ0IsQ0FBQ1UsVUFBVTtBQUN6QixVQUFJbEIsVUFBUztBQUNYa0IsY0FBTUMsSUFBSSxXQUFXbkIsUUFBTztBQUFBLE1BQzlCLE9BQU87QUFDTGtCLGNBQU1FLE9BQU8sU0FBUztBQUFBLE1BQ3hCO0FBRUEsVUFBSWpCLGVBQWM7QUFDaEJlLGNBQU1DLElBQUksZ0JBQWdCaEIsYUFBWTtBQUFBLE1BQ3hDLE9BQU87QUFDTGUsY0FBTUUsT0FBTyxjQUFjO0FBQUEsTUFDN0I7QUFFQSxVQUFJaEIsU0FBUTtBQUNWYyxjQUFNQyxJQUFJLFVBQVVmLE9BQU07QUFBQSxNQUM1QixPQUFPO0FBQ0xjLGNBQU1FLE9BQU8sUUFBUTtBQUFBLE1BQ3ZCO0FBRUFGLFlBQU1DLElBQUksUUFBUSxHQUFHO0FBRXJCLGFBQU9EO0FBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTRyxxQkFBcUI7QUFDNUJiLG9CQUFnQixDQUFDVSxVQUFVO0FBQ3pCQSxZQUFNRSxPQUFPLFNBQVM7QUFDdEJGLFlBQU1FLE9BQU8sY0FBYztBQUMzQkYsWUFBTUUsT0FBTyxRQUFRO0FBQ3JCRixZQUFNQyxJQUFJLFFBQVEsR0FBRztBQUVyQixhQUFPRDtBQUFBQSxJQUNULENBQUM7QUFFREwsVUFBTTtBQUFBLE1BQ0piLFNBQVM7QUFBQSxNQUNURyxjQUFjO0FBQUEsTUFDZEMsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxVQUFVTyxhQUFhTSxZQUFZO0FBQUEsTUFDbkMsV0FBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxVQUFLLFdBQVUseUJBQXdCLHdCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsUUFDaEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWLEdBQUlQLFNBQVMsU0FBUztBQUFBO0FBQUEsVUFIeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRzBCO0FBQUEsUUFFMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWLEdBQUlBLFNBQVMsY0FBYztBQUFBO0FBQUEsVUFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRytCO0FBQUEsUUFFL0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMO0FBQUEsWUFDQSxRQUFRLENBQUMsRUFBRVksT0FBTyxFQUFFQyxNQUFNQyxVQUFVQyxPQUFPQyxTQUFTLEVBQUUsTUFBTTtBQUMxRCxxQkFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxjQUFhO0FBQUEsa0JBQ2I7QUFBQSxrQkFDQSxlQUFlRjtBQUFBQSxrQkFDZjtBQUFBLGtCQUNBO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxpQkFBYyxXQUFVLGlCQUN2QixpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFZLEtBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLGlCQUNDO0FBQUEsNkNBQUMsY0FBVyxPQUFNLE9BQU0sNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9DO0FBQUEsc0JBQ3BDLHVCQUFDLGNBQVcsT0FBTSxXQUFVLHdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQztBQUFBLHNCQUNwQyx1QkFBQyxjQUFXLE9BQU0sWUFBVyx5QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0M7QUFBQSxzQkFDdEMsdUJBQUMsY0FBVyxPQUFNLGNBQWEsMEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlDO0FBQUEsc0JBQ3pDLHVCQUFDLGNBQVcsT0FBTSxjQUFhLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxjQUFXLE9BQU0sYUFBWSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0M7QUFBQSx5QkFOeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBO0FBQUE7QUFBQSxnQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0JBO0FBQUEsWUFFSjtBQUFBO0FBQUEsVUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBeUJJO0FBQUEsUUFHSix1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLGFBQVksTUFBSyxNQUM3QztBQUFBLGlDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFHO0FBQUEsYUFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU0g7QUFBQUEsWUFDVCxNQUFLO0FBQUEsWUFDTCxTQUFRO0FBQUEsWUFDUixNQUFLO0FBQUEsWUFFTDtBQUFBLHFDQUFDLEtBQUUsV0FBVSxrQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQUc7QUFBQTtBQUFBO0FBQUEsVUFOaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQTtBQUFBO0FBQUEsSUF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBeURBO0FBRUo7QUFBQ2YsR0F4SGVELG1CQUFpQjtBQUFBLFVBQ1NoQixpQkFPdENELE9BQU87QUFBQTtBQUFBdUMsS0FSS3RCO0FBQWlCLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU2VhcmNoIiwiWCIsIkNvbnRyb2xsZXIiLCJ1c2VGb3JtIiwidXNlU2VhcmNoUGFyYW1zIiwieiIsIkJ1dHRvbiIsIklucHV0IiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJvcmRlckZpbHRlcnNTY2hlbWEiLCJvYmplY3QiLCJvcmRlcklkIiwic3RyaW5nIiwib3B0aW9uYWwiLCJjdXN0b21lck5hbWUiLCJzdGF0dXMiLCJPcmRlclRhYmxlRmlsdGVycyIsIl9zIiwic2VhcmNoUGFyYW1zIiwic2V0U2VhcmNoUGFyYW1zIiwiZ2V0IiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJjb250cm9sIiwicmVzZXQiLCJyZXNvbHZlciIsInpvZFJlc29sdmVyIiwiZGVmYXVsdFZhbHVlcyIsImhhbmRsZUZpdGxlciIsInN0YXRlIiwic2V0IiwiZGVsZXRlIiwiaGFuZGxlQ2xlYXJGaWx0ZXJzIiwiZmllbGQiLCJuYW1lIiwib25DaGFuZ2UiLCJ2YWx1ZSIsImRpc2FibGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJvcmRlci10YWJsZS1maWx0ZXJzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gJ0Bob29rZm9ybS9yZXNvbHZlcnMvem9kJ1xyXG5pbXBvcnQgeyBTZWFyY2gsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IENvbnRyb2xsZXIsIHVzZUZvcm0gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXHJcbmltcG9ydCB7IHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXHJcblxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcclxuaW1wb3J0IHtcclxuICBTZWxlY3QsXHJcbiAgU2VsZWN0Q29udGVudCxcclxuICBTZWxlY3RJdGVtLFxyXG4gIFNlbGVjdFRyaWdnZXIsXHJcbiAgU2VsZWN0VmFsdWUsXHJcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NlbGVjdCdcclxuXHJcbmNvbnN0IG9yZGVyRmlsdGVyc1NjaGVtYSA9IHoub2JqZWN0KHtcclxuICBvcmRlcklkOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgY3VzdG9tZXJOYW1lOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgc3RhdHVzOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbn0pXHJcblxyXG50eXBlIE9yZGVyRmlsdGVyc1NjaGVtYSA9IHouaW5mZXI8dHlwZW9mIG9yZGVyRmlsdGVyc1NjaGVtYT5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBPcmRlclRhYmxlRmlsdGVycygpIHtcclxuICBjb25zdCBbc2VhcmNoUGFyYW1zLCBzZXRTZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcclxuXHJcbiAgY29uc3Qgb3JkZXJJZCA9IHNlYXJjaFBhcmFtcy5nZXQoJ29yZGVySWQnKVxyXG4gIGNvbnN0IGN1c3RvbWVyTmFtZSA9IHNlYXJjaFBhcmFtcy5nZXQoJ2N1c3RvbWVyTmFtZScpXHJcbiAgY29uc3Qgc3RhdHVzID0gc2VhcmNoUGFyYW1zLmdldCgnc3RhdHVzJylcclxuXHJcbiAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBjb250cm9sLCByZXNldCB9ID1cclxuICAgIHVzZUZvcm08T3JkZXJGaWx0ZXJzU2NoZW1hPih7XHJcbiAgICAgIHJlc29sdmVyOiB6b2RSZXNvbHZlcihvcmRlckZpbHRlcnNTY2hlbWEpLFxyXG4gICAgICBkZWZhdWx0VmFsdWVzOiB7XHJcbiAgICAgICAgb3JkZXJJZDogb3JkZXJJZCA/PyAnJyxcclxuICAgICAgICBjdXN0b21lck5hbWU6IGN1c3RvbWVyTmFtZSA/PyAnJyxcclxuICAgICAgICBzdGF0dXM6IHN0YXR1cyA/PyAnYWxsJyxcclxuICAgICAgfSxcclxuICAgIH0pXHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZUZpdGxlcih7IG9yZGVySWQsIGN1c3RvbWVyTmFtZSwgc3RhdHVzIH06IE9yZGVyRmlsdGVyc1NjaGVtYSkge1xyXG4gICAgc2V0U2VhcmNoUGFyYW1zKChzdGF0ZSkgPT4ge1xyXG4gICAgICBpZiAob3JkZXJJZCkge1xyXG4gICAgICAgIHN0YXRlLnNldCgnb3JkZXJJZCcsIG9yZGVySWQpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc3RhdGUuZGVsZXRlKCdvcmRlcklkJylcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGN1c3RvbWVyTmFtZSkge1xyXG4gICAgICAgIHN0YXRlLnNldCgnY3VzdG9tZXJOYW1lJywgY3VzdG9tZXJOYW1lKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHN0YXRlLmRlbGV0ZSgnY3VzdG9tZXJOYW1lJylcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHN0YXR1cykge1xyXG4gICAgICAgIHN0YXRlLnNldCgnc3RhdHVzJywgc3RhdHVzKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHN0YXRlLmRlbGV0ZSgnc3RhdHVzJylcclxuICAgICAgfVxyXG5cclxuICAgICAgc3RhdGUuc2V0KCdwYWdlJywgJzEnKVxyXG5cclxuICAgICAgcmV0dXJuIHN0YXRlXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ2xlYXJGaWx0ZXJzKCkge1xyXG4gICAgc2V0U2VhcmNoUGFyYW1zKChzdGF0ZSkgPT4ge1xyXG4gICAgICBzdGF0ZS5kZWxldGUoJ29yZGVySWQnKVxyXG4gICAgICBzdGF0ZS5kZWxldGUoJ2N1c3RvbWVyTmFtZScpXHJcbiAgICAgIHN0YXRlLmRlbGV0ZSgnc3RhdHVzJylcclxuICAgICAgc3RhdGUuc2V0KCdwYWdlJywgJzEnKVxyXG5cclxuICAgICAgcmV0dXJuIHN0YXRlXHJcbiAgICB9KVxyXG5cclxuICAgIHJlc2V0KHtcclxuICAgICAgb3JkZXJJZDogJycsXHJcbiAgICAgIGN1c3RvbWVyTmFtZTogJycsXHJcbiAgICAgIHN0YXR1czogJ2FsbCcsXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtXHJcbiAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQoaGFuZGxlRml0bGVyKX1cclxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5GaWx0cm9zOjwvc3Bhbj5cclxuICAgICAgPElucHV0XHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJJRCBkbyBwZWRpZG9cIlxyXG4gICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LWF1dG9cIlxyXG4gICAgICAgIHsuLi5yZWdpc3Rlcignb3JkZXJJZCcpfVxyXG4gICAgICAvPlxyXG4gICAgICA8SW5wdXRcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZG8gY2xpZW50ZVwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctWzMyMHB4XVwiXHJcbiAgICAgICAgey4uLnJlZ2lzdGVyKCdjdXN0b21lck5hbWUnKX1cclxuICAgICAgLz5cclxuICAgICAgPENvbnRyb2xsZXJcclxuICAgICAgICBuYW1lPVwic3RhdHVzXCJcclxuICAgICAgICBjb250cm9sPXtjb250cm9sfVxyXG4gICAgICAgIHJlbmRlcj17KHsgZmllbGQ6IHsgbmFtZSwgb25DaGFuZ2UsIHZhbHVlLCBkaXNhYmxlZCB9IH0pID0+IHtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9XCJhbGxcIlxyXG4gICAgICAgICAgICAgIG5hbWU9e25hbWV9XHJcbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17b25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOCB3LVsxODBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSAvPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+VG9kb3Mgc3RhdHVzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJwZW5kaW5nXCI+UGVuZGVudGU8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImNhbmNlbGVkXCI+Q2FuY2VsYWRvPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJwcm9jZXNzaW5nXCI+RW0gcHJlcGFybzwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiZGVsaXZlcmluZ1wiPkVtIGVudHJlZ2E8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImRlbGl2ZXJlZFwiPkVudHJlZ3VlPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfX1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBzaXplPVwieHNcIj5cclxuICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XHJcbiAgICAgICAgRmlsdHJhciByZXN1bHRhZG9zXHJcbiAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgPEJ1dHRvblxyXG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFyRmlsdGVyc31cclxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXHJcbiAgICAgICAgc2l6ZT1cInhzXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxYIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XHJcbiAgICAgICAgUmVtb3ZlciBmaWx0cm9zXHJcbiAgICAgIDwvQnV0dG9uPlxyXG4gICAgPC9mb3JtPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL29yZGVycy9vcmRlci10YWJsZS1maWx0ZXJzLnRzeCJ9