import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { createBrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { AppLayout } from "/src/pages/_layouts/app.tsx?t=1713877714374";
import { AuthLayout } from "/src/pages/_layouts/auth.tsx";
import { NotFound } from "/src/pages/404.tsx";
import { Dashboard } from "/src/pages/app/dashboard/dashboard.tsx?t=1713839676892";
import { Orders } from "/src/pages/app/orders/orders.tsx?t=1713894108050";
import { SignIn } from "/src/pages/auth/sign-in.tsx";
import { SignUp } from "/src/pages/auth/sign-up.tsx?t=1713917016034";
import { Error } from "/src/pages/error.tsx";
export const router = createBrowserRouter(
  [
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(AppLayout, {}, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
        lineNumber: 15,
        columnNumber: 12
      }, this),
      errorElement: /* @__PURE__ */ jsxDEV(Error, {}, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
        lineNumber: 16,
        columnNumber: 17
      }, this),
      children: [
        { path: "/", element: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
          lineNumber: 18,
          columnNumber: 25
        }, this) },
        { path: "/orders", element: /* @__PURE__ */ jsxDEV(Orders, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
          lineNumber: 19,
          columnNumber: 31
        }, this) }
      ]
    },
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(AuthLayout, {}, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
        lineNumber: 24,
        columnNumber: 12
      }, this),
      children: [
        { path: "/sign-in", element: /* @__PURE__ */ jsxDEV(SignIn, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
          lineNumber: 26,
          columnNumber: 32
        }, this) },
        { path: "/sign-up", element: /* @__PURE__ */ jsxDEV(SignUp, {}, void 0, false, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
          lineNumber: 27,
          columnNumber: 32
        }, this) }
      ]
    },
    {
      path: "*",
      element: /* @__PURE__ */ jsxDEV(NotFound, {}, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/routes.tsx",
        lineNumber: 32,
        columnNumber: 12
      }, this)
    }
  ]
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY2E7QUFkYixTQUFTQSwyQkFBMkI7QUFFcEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFFZixhQUFNQyxTQUFTVDtBQUFBQSxFQUFvQjtBQUFBLElBQ3hDO0FBQUEsTUFDRVUsTUFBTTtBQUFBLE1BQ05DLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNuQkMsY0FBYyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTTtBQUFBLE1BQ3BCQyxVQUFVO0FBQUEsUUFDUixFQUFFSCxNQUFNLEtBQUtDLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVUsRUFBSTtBQUFBLFFBQ3BDLEVBQUVELE1BQU0sV0FBV0MsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxFQUFJO0FBQUEsTUFBQztBQUFBLElBRTVDO0FBQUEsSUFDQTtBQUFBLE1BQ0VELE1BQU07QUFBQSxNQUNOQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQ3BCRSxVQUFVO0FBQUEsUUFDUixFQUFFSCxNQUFNLFlBQVlDLFNBQVMsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU8sRUFBSTtBQUFBLFFBQ3hDLEVBQUVELE1BQU0sWUFBWUMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxFQUFJO0FBQUEsTUFBQztBQUFBLElBRTdDO0FBQUEsSUFDQTtBQUFBLE1BQ0VELE1BQU07QUFBQSxNQUNOQyxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTO0FBQUEsSUFDcEI7QUFBQSxFQUFDO0FBQ0YiLCJuYW1lcyI6WyJjcmVhdGVCcm93c2VyUm91dGVyIiwiQXBwTGF5b3V0IiwiQXV0aExheW91dCIsIk5vdEZvdW5kIiwiRGFzaGJvYXJkIiwiT3JkZXJzIiwiU2lnbkluIiwiU2lnblVwIiwiRXJyb3IiLCJyb3V0ZXIiLCJwYXRoIiwiZWxlbWVudCIsImVycm9yRWxlbWVudCIsImNoaWxkcmVuIl0sInNvdXJjZXMiOlsicm91dGVzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuXHJcbmltcG9ydCB7IEFwcExheW91dCB9IGZyb20gJy4vcGFnZXMvX2xheW91dHMvYXBwJ1xyXG5pbXBvcnQgeyBBdXRoTGF5b3V0IH0gZnJvbSAnLi9wYWdlcy9fbGF5b3V0cy9hdXRoJ1xyXG5pbXBvcnQgeyBOb3RGb3VuZCB9IGZyb20gJy4vcGFnZXMvNDA0J1xyXG5pbXBvcnQgeyBEYXNoYm9hcmQgfSBmcm9tICcuL3BhZ2VzL2FwcC9kYXNoYm9hcmQvZGFzaGJvYXJkJ1xyXG5pbXBvcnQgeyBPcmRlcnMgfSBmcm9tICcuL3BhZ2VzL2FwcC9vcmRlcnMvb3JkZXJzJ1xyXG5pbXBvcnQgeyBTaWduSW4gfSBmcm9tICcuL3BhZ2VzL2F1dGgvc2lnbi1pbidcclxuaW1wb3J0IHsgU2lnblVwIH0gZnJvbSAnLi9wYWdlcy9hdXRoL3NpZ24tdXAnXHJcbmltcG9ydCB7IEVycm9yIH0gZnJvbSAnLi9wYWdlcy9lcnJvcidcclxuXHJcbmV4cG9ydCBjb25zdCByb3V0ZXIgPSBjcmVhdGVCcm93c2VyUm91dGVyKFtcclxuICB7XHJcbiAgICBwYXRoOiAnLycsXHJcbiAgICBlbGVtZW50OiA8QXBwTGF5b3V0IC8+LFxyXG4gICAgZXJyb3JFbGVtZW50OiA8RXJyb3IgLz4sXHJcbiAgICBjaGlsZHJlbjogW1xyXG4gICAgICB7IHBhdGg6ICcvJywgZWxlbWVudDogPERhc2hib2FyZCAvPiB9LFxyXG4gICAgICB7IHBhdGg6ICcvb3JkZXJzJywgZWxlbWVudDogPE9yZGVycyAvPiB9LFxyXG4gICAgXSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6ICcvJyxcclxuICAgIGVsZW1lbnQ6IDxBdXRoTGF5b3V0IC8+LFxyXG4gICAgY2hpbGRyZW46IFtcclxuICAgICAgeyBwYXRoOiAnL3NpZ24taW4nLCBlbGVtZW50OiA8U2lnbkluIC8+IH0sXHJcbiAgICAgIHsgcGF0aDogJy9zaWduLXVwJywgZWxlbWVudDogPFNpZ25VcCAvPiB9LFxyXG4gICAgXSxcclxuICB9LFxyXG4gIHtcclxuICAgIHBhdGg6ICcqJyxcclxuICAgIGVsZW1lbnQ6IDxOb3RGb3VuZCAvPixcclxuICB9LFxyXG5dKVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcm91dGVzLnRzeCJ9