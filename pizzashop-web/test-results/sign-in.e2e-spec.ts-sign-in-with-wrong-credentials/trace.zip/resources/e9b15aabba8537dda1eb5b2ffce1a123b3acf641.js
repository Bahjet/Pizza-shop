import {
  require_react
} from "/node_modules/.vite/deps/chunk-KXJ7H7NM.js?v=12cb1194";
import "/node_modules/.vite/deps/chunk-TIUEEL27.js?v=12cb1194";
export default require_react();
//# sourceMappingURL=react.js.map
