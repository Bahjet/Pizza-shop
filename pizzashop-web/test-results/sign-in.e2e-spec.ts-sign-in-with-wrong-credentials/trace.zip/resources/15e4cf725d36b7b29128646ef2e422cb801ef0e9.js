import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=12cb1194"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=12cb1194"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { enableMSW } from "/src/api/mocks/index.ts?t=1714068039359";
import { App } from "/src/app.tsx?t=1714068039359";
enableMSW().then(() => {
  ReactDOM.createRoot(document.getElementById("root")).render(
    /* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/main.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/main.tsx",
      lineNumber: 9,
      columnNumber: 5
    }, this)
  );
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFFckIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFdBQVc7QUFFcEJELFVBQVUsRUFBRUUsS0FBSyxNQUFNO0FBQ3JCSCxXQUFTSSxXQUFXQyxTQUFTQyxlQUFlLE1BQU0sQ0FBRSxFQUFFQztBQUFBQSxJQUNwRCx1QkFBQyxNQUFNLFlBQU4sRUFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsImVuYWJsZU1TVyIsIkFwcCIsInRoZW4iLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXHJcblxyXG5pbXBvcnQgeyBlbmFibGVNU1cgfSBmcm9tICcuL2FwaS9tb2NrcydcclxuaW1wb3J0IHsgQXBwIH0gZnJvbSAnLi9hcHAnXHJcblxyXG5lbmFibGVNU1coKS50aGVuKCgpID0+IHtcclxuICBSZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykhKS5yZW5kZXIoXHJcbiAgICA8UmVhY3QuU3RyaWN0TW9kZT5cclxuICAgICAgPEFwcCAvPlxyXG4gICAgPC9SZWFjdC5TdHJpY3RNb2RlPixcclxuICApXHJcbn0pXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9tYWluLnRzeCJ9