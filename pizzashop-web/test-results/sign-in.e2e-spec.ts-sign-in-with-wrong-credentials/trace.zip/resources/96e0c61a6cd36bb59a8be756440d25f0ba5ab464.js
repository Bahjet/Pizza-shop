import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/_layouts/app.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { isAxiosError } from "/node_modules/.vite/deps/axios.js?v=12cb1194";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=12cb1194"; const useEffect = __vite__cjsImport4_react["useEffect"];
import { Outlet, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { Header } from "/src/components/header.tsx?t=1713839672183";
import { api } from "/src/lib/axios.ts";
export function AppLayout() {
  _s();
  const navigate = useNavigate();
  useEffect(() => {
    const interceptorId = api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (isAxiosError(error)) {
          const status = error.response?.status;
          const code = error.response?.data.code;
          if (status === 401 && code === "UNAUTHORIZED") {
            navigate("/sign-in", { replace: true });
          } else {
            throw error;
          }
        }
      }
    );
    return () => {
      api.interceptors.response.eject(interceptorId);
    };
  }, [navigate]);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen flex-col antialiased", children: [
    /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col gap-4 p-8 pt-6", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx",
      lineNumber: 38,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}
_s(AppLayout, "0pNeyzXk/ByIxyERsdaIrG6js9s=", false, function() {
  return [useNavigate];
});
_c = AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/_layouts/app.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NNOzJCQWxDTjtBQUFxQixvQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwQyxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsUUFBUUMsbUJBQW1CO0FBRXBDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsV0FBVztBQUViLGdCQUFTQyxZQUFZO0FBQUFDLEtBQUE7QUFDMUIsUUFBTUMsV0FBV0wsWUFBWTtBQUc3QkYsWUFBVSxNQUFNO0FBQ2QsVUFBTVEsZ0JBQWdCSixJQUFJSyxhQUFhQyxTQUFTQztBQUFBQSxNQUM5QyxDQUFDRCxhQUFhQTtBQUFBQSxNQUNkLENBQUNFLFVBQVU7QUFDVCxZQUFJQyxhQUFhRCxLQUFLLEdBQUc7QUFDdkIsZ0JBQU1FLFNBQVNGLE1BQU1GLFVBQVVJO0FBQy9CLGdCQUFNQyxPQUFPSCxNQUFNRixVQUFVTSxLQUFLRDtBQUVsQyxjQUFJRCxXQUFXLE9BQU9DLFNBQVMsZ0JBQWdCO0FBQzdDUixxQkFBUyxZQUFZLEVBQUVVLFNBQVMsS0FBSyxDQUFDO0FBQUEsVUFDeEMsT0FBTztBQUNMLGtCQUFNTDtBQUFBQSxVQUNSO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxNQUFNO0FBQ1hSLFVBQUlLLGFBQWFDLFNBQVNRLE1BQU1WLGFBQWE7QUFBQSxJQUMvQztBQUFBLEVBQ0YsR0FBRyxDQUFDRCxRQUFRLENBQUM7QUFFYixTQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFFUCx1QkFBQyxTQUFJLFdBQVUsdUNBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNELEdBbENlRCxXQUFTO0FBQUEsVUFDTkgsV0FBVztBQUFBO0FBQUFpQixLQURkZDtBQUFTLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJPdXRsZXQiLCJ1c2VOYXZpZ2F0ZSIsIkhlYWRlciIsImFwaSIsIkFwcExheW91dCIsIl9zIiwibmF2aWdhdGUiLCJpbnRlcmNlcHRvcklkIiwiaW50ZXJjZXB0b3JzIiwicmVzcG9uc2UiLCJ1c2UiLCJlcnJvciIsImlzQXhpb3NFcnJvciIsInN0YXR1cyIsImNvZGUiLCJkYXRhIiwicmVwbGFjZSIsImVqZWN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzQXhpb3NFcnJvciB9IGZyb20gJ2F4aW9zJ1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgT3V0bGV0LCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcblxyXG5pbXBvcnQgeyBIZWFkZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvaGVhZGVyJ1xyXG5pbXBvcnQgeyBhcGkgfSBmcm9tICdAL2xpYi9heGlvcydcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBcHBMYXlvdXQoKSB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcblxyXG4gIC8vIHZvbHRhciBvIGEgcGFnaW5hIGluaWNpYWwgY2FzbyBuw6NvIGVzdGVqYSBhdXRlbnRpY2Fkb1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBpbnRlcmNlcHRvcklkID0gYXBpLmludGVyY2VwdG9ycy5yZXNwb25zZS51c2UoXHJcbiAgICAgIChyZXNwb25zZSkgPT4gcmVzcG9uc2UsXHJcbiAgICAgIChlcnJvcikgPT4ge1xyXG4gICAgICAgIGlmIChpc0F4aW9zRXJyb3IoZXJyb3IpKSB7XHJcbiAgICAgICAgICBjb25zdCBzdGF0dXMgPSBlcnJvci5yZXNwb25zZT8uc3RhdHVzXHJcbiAgICAgICAgICBjb25zdCBjb2RlID0gZXJyb3IucmVzcG9uc2U/LmRhdGEuY29kZVxyXG5cclxuICAgICAgICAgIGlmIChzdGF0dXMgPT09IDQwMSAmJiBjb2RlID09PSAnVU5BVVRIT1JJWkVEJykge1xyXG4gICAgICAgICAgICBuYXZpZ2F0ZSgnL3NpZ24taW4nLCB7IHJlcGxhY2U6IHRydWUgfSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRocm93IGVycm9yXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgKVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgYXBpLmludGVyY2VwdG9ycy5yZXNwb25zZS5lamVjdChpbnRlcmNlcHRvcklkKVxyXG4gICAgfVxyXG4gIH0sIFtuYXZpZ2F0ZV0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGZsZXgtY29sIGFudGlhbGlhc2VkXCI+XHJcbiAgICAgIDxIZWFkZXIgLz5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgZ2FwLTQgcC04IHB0LTZcIj5cclxuICAgICAgICA8T3V0bGV0IC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9wYWdlcy9fbGF5b3V0cy9hcHAudHN4In0=