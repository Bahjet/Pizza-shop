import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/date-range-picker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
"use client";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=12cb1194";
import { Calendar as CalendarIcon } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { Button } from "/src/components/ui/button.tsx";
import { Calendar } from "/src/components/ui/calendar.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "/src/components/ui/popover.tsx";
import { cn } from "/src/lib/utils.ts";
export function DateRangePicker({
  className,
  date,
  onDateChange
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: cn("grid gap-2", className), children: /* @__PURE__ */ jsxDEV(Popover, { children: [
    /* @__PURE__ */ jsxDEV(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        id: "date",
        variant: "outline",
        className: cn(
          "w-[300px] justify-start text-left font-normal",
          !date && "text-muted-foreground"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(CalendarIcon, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
            lineNumber: 39,
            columnNumber: 13
          }, this),
          date?.from ? date.to ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            format(date.from, "LLL dd, y"),
            " -",
            " ",
            format(date.to, "LLL dd, y")
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
            lineNumber: 42,
            columnNumber: 13
          }, this) : format(date.from, "LLL dd, y") : /* @__PURE__ */ jsxDEV("span", { children: "Pick a date" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
            lineNumber: 50,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
        lineNumber: 31,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PopoverContent, { className: "w-auto p-0", align: "start", children: /* @__PURE__ */ jsxDEV(
      Calendar,
      {
        initialFocus: true,
        mode: "range",
        defaultMonth: date?.from,
        selected: date,
        onSelect: onDateChange,
        numberOfMonths: 2
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
        lineNumber: 55,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
}
_c = DateRangePicker;
var _c;
$RefreshReg$(_c, "DateRangePicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/components/ui/date-range-picker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NZLFNBR0ksVUFISjtBQXRDWiwyQkFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVaLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsWUFBWUMsb0JBQW9CO0FBSXpDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0YsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUc7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFVBQVU7QUFPWixnQkFBU0MsZ0JBQWdCO0FBQUEsRUFDOUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ29CLEdBQUc7QUFDdkIsU0FDRSx1QkFBQyxTQUFJLFdBQVdKLEdBQUcsY0FBY0UsU0FBUyxHQUN4QyxpQ0FBQyxXQUNDO0FBQUEsMkJBQUMsa0JBQWUsU0FBTyxNQUNyQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsU0FBUztBQUFBLFFBQ1QsV0FBV0Y7QUFBQUEsVUFDVDtBQUFBLFVBQ0EsQ0FBQ0csUUFBUTtBQUFBLFFBQ1g7QUFBQSxRQUVBO0FBQUEsaUNBQUMsZ0JBQWEsV0FBVSxrQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUNyQ0EsTUFBTUUsT0FDTEYsS0FBS0csS0FDSCxtQ0FDR2I7QUFBQUEsbUJBQU9VLEtBQUtFLE1BQU0sV0FBVztBQUFBLFlBQUU7QUFBQSxZQUFHO0FBQUEsWUFDbENaLE9BQU9VLEtBQUtHLElBQUksV0FBVztBQUFBLGVBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsSUFFQWIsT0FBT1UsS0FBS0UsTUFBTSxXQUFXLElBRy9CLHVCQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQTtBQUFBO0FBQUEsTUFuQnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFDQSx1QkFBQyxrQkFBZSxXQUFVLGNBQWEsT0FBTSxTQUMzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLE1BQUs7QUFBQSxRQUNMLGNBQWNGLE1BQU1FO0FBQUFBLFFBQ3BCLFVBQVVGO0FBQUFBLFFBQ1YsVUFBVUM7QUFBQUEsUUFDVixnQkFBZ0I7QUFBQTtBQUFBLE1BTmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1vQixLQVB0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxPQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQ0E7QUFFSjtBQUFDRyxLQTdDZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiZm9ybWF0IiwiQ2FsZW5kYXIiLCJDYWxlbmRhckljb24iLCJCdXR0b24iLCJQb3BvdmVyIiwiUG9wb3ZlckNvbnRlbnQiLCJQb3BvdmVyVHJpZ2dlciIsImNuIiwiRGF0ZVJhbmdlUGlja2VyIiwiY2xhc3NOYW1lIiwiZGF0ZSIsIm9uRGF0ZUNoYW5nZSIsImZyb20iLCJ0byIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGF0ZS1yYW5nZS1waWNrZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50J1xyXG5cclxuaW1wb3J0IHsgZm9ybWF0IH0gZnJvbSAnZGF0ZS1mbnMnXHJcbmltcG9ydCB7IENhbGVuZGFyIGFzIENhbGVuZGFySWNvbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IERhdGVSYW5nZSB9IGZyb20gJ3JlYWN0LWRheS1waWNrZXInXHJcblxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBDYWxlbmRhciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYWxlbmRhcidcclxuaW1wb3J0IHtcclxuICBQb3BvdmVyLFxyXG4gIFBvcG92ZXJDb250ZW50LFxyXG4gIFBvcG92ZXJUcmlnZ2VyLFxyXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9wb3BvdmVyJ1xyXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xyXG5cclxuaW50ZXJmYWNlIERhdGVSYW5nZVBpY2tlclByb3BzIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50UHJvcHM8J2Rpdic+IHtcclxuICBkYXRlOiBEYXRlUmFuZ2UgfCB1bmRlZmluZWRcclxuICBvbkRhdGVDaGFuZ2U6IChkYXRlOiBEYXRlUmFuZ2UgfCB1bmRlZmluZWQpID0+IHZvaWRcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIERhdGVSYW5nZVBpY2tlcih7XHJcbiAgY2xhc3NOYW1lLFxyXG4gIGRhdGUsXHJcbiAgb25EYXRlQ2hhbmdlLFxyXG59OiBEYXRlUmFuZ2VQaWNrZXJQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17Y24oJ2dyaWQgZ2FwLTInLCBjbGFzc05hbWUpfT5cclxuICAgICAgPFBvcG92ZXI+XHJcbiAgICAgICAgPFBvcG92ZXJUcmlnZ2VyIGFzQ2hpbGQ+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9eydvdXRsaW5lJ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcclxuICAgICAgICAgICAgICAndy1bMzAwcHhdIGp1c3RpZnktc3RhcnQgdGV4dC1sZWZ0IGZvbnQtbm9ybWFsJyxcclxuICAgICAgICAgICAgICAhZGF0ZSAmJiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kJyxcclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPENhbGVuZGFySWNvbiBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICB7ZGF0ZT8uZnJvbSA/IChcclxuICAgICAgICAgICAgICBkYXRlLnRvID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdChkYXRlLmZyb20sICdMTEwgZGQsIHknKX0gLXsnICd9XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtYXQoZGF0ZS50bywgJ0xMTCBkZCwgeScpfVxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIGZvcm1hdChkYXRlLmZyb20sICdMTEwgZGQsIHknKVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8c3Bhbj5QaWNrIGEgZGF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvUG9wb3ZlclRyaWdnZXI+XHJcbiAgICAgICAgPFBvcG92ZXJDb250ZW50IGNsYXNzTmFtZT1cInctYXV0byBwLTBcIiBhbGlnbj1cInN0YXJ0XCI+XHJcbiAgICAgICAgICA8Q2FsZW5kYXJcclxuICAgICAgICAgICAgaW5pdGlhbEZvY3VzXHJcbiAgICAgICAgICAgIG1vZGU9XCJyYW5nZVwiXHJcbiAgICAgICAgICAgIGRlZmF1bHRNb250aD17ZGF0ZT8uZnJvbX1cclxuICAgICAgICAgICAgc2VsZWN0ZWQ9e2RhdGV9XHJcbiAgICAgICAgICAgIG9uU2VsZWN0PXtvbkRhdGVDaGFuZ2V9XHJcbiAgICAgICAgICAgIG51bWJlck9mTW9udGhzPXsyfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L1BvcG92ZXJDb250ZW50PlxyXG4gICAgICA8L1BvcG92ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BY2VyIE5pdHJvIDUvRGVza3RvcC9yb2NrZXRzZWF0L2lnbml0ZS9yZWFjdC9yZWFjdC00L3Bpenphc2hvcC13ZWIvc3JjL2NvbXBvbmVudHMvdWkvZGF0ZS1yYW5nZS1waWNrZXIudHN4In0=