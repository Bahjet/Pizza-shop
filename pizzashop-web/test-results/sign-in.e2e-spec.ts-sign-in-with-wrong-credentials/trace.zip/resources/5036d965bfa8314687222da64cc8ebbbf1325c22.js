import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-up.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=12cb1194";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=12cb1194";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=12cb1194";
import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
import { registerRestaurant } from "/src/api/register-restaurant.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signUpForm = z.object({
  restaurantName: z.string(),
  managerName: z.string(),
  phone: z.string(),
  email: z.string().email()
});
export function SignUp() {
  _s();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm();
  const { mutateAsync: registerRestaurantFn } = useMutation({
    mutationFn: registerRestaurant
  });
  async function handleSignUp(data) {
    try {
      await registerRestaurantFn({
        restaurantName: data.restaurantName,
        managerName: data.managerName,
        email: data.email,
        phone: data.phone
      });
      toast.success("Restaurante cadastrado com sucesso!", {
        action: {
          label: "Reenviar",
          onClick: () => navigate(`/sign-in?email=${data.email}`)
        }
      });
    } catch {
      toast.error("Erro ao cadastrar restaurante.");
    }
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Cadastro" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", asChild: true, className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-in", children: "Fazer login" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
        lineNumber: 59,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight ", children: "Criar conta grátis" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Seja um parceira e comece suas vendas!" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 66,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleSubmit(handleSignUp), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "restaurantName", children: "Nome do estabelecimento" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 73,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "restaurantName",
                type: "text",
                ...register("restaurantName")
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
                lineNumber: 74,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "managerName", children: "Seu nome" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 82,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "managerName",
                type: "text",
                ...register("managerName")
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
                lineNumber: 83,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 81,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 91,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "email", type: "email", ...register("email") }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 92,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 90,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "phone", children: "Seu celular" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 96,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "phone", type: "tel", ...register("phone") }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 97,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, className: "w-full", type: "submit", children: "Finalizar cadastro" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 100,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "px-6 text-center text-sm leading-relaxed text-muted-foreground", children: [
            "Ao continuar, você concorda com nossos",
            " ",
            /* @__PURE__ */ jsxDEV("a", { className: "underline underline-offset-4", href: "", children: "termos de serviço" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 106,
              columnNumber: 15
            }, this),
            " ",
            "e",
            " ",
            /* @__PURE__ */ jsxDEV("a", { className: "underline underline-offset-4", href: "", children: "politicas de privacidade" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
              lineNumber: 110,
              columnNumber: 15
            }, this),
            "."
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
            lineNumber: 104,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
          lineNumber: 71,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx",
    lineNumber: 55,
    columnNumber: 5
  }, this);
}
_s(SignUp, "zfeW/S2y6tCmLAwMa9nFXjDJrjg=", false, function() {
  return [useNavigate, useForm, useMutation];
});
_c = SignUp;
var _c;
$RefreshReg$(_c, "SignUp");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-up.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RJLG1CQUNFLGNBREY7MkJBdERKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsYUFBYUwsRUFBRU0sT0FBTztBQUFBLEVBQzFCQyxnQkFBZ0JQLEVBQUVRLE9BQU87QUFBQSxFQUN6QkMsYUFBYVQsRUFBRVEsT0FBTztBQUFBLEVBQ3RCRSxPQUFPVixFQUFFUSxPQUFPO0FBQUEsRUFDaEJHLE9BQU9YLEVBQUVRLE9BQU8sRUFBRUcsTUFBTTtBQUMxQixDQUFDO0FBSU0sZ0JBQVNDLFNBQVM7QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXaEIsWUFBWTtBQUU3QixRQUFNO0FBQUEsSUFDSmlCO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUl0QixRQUFvQjtBQUV4QixRQUFNLEVBQUV1QixhQUFhQyxxQkFBcUIsSUFBSUMsWUFBWTtBQUFBLElBQ3hEQyxZQUFZckI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsaUJBQWVzQixhQUFhQyxNQUFrQjtBQUM1QyxRQUFJO0FBQ0YsWUFBTUoscUJBQXFCO0FBQUEsUUFDekJiLGdCQUFnQmlCLEtBQUtqQjtBQUFBQSxRQUNyQkUsYUFBYWUsS0FBS2Y7QUFBQUEsUUFDbEJFLE9BQU9hLEtBQUtiO0FBQUFBLFFBQ1pELE9BQU9jLEtBQUtkO0FBQUFBLE1BQ2QsQ0FBQztBQUNEWCxZQUFNMEIsUUFBUSx1Q0FBdUM7QUFBQSxRQUNuREMsUUFBUTtBQUFBLFVBQ05DLE9BQU87QUFBQSxVQUNQQyxTQUFTQSxNQUFNZCxTQUFVLGtCQUFpQlUsS0FBS2IsS0FBTSxFQUFDO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFFBQVE7QUFDTlosWUFBTThCLE1BQU0sZ0NBQWdDO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFVBQU8sT0FBTSxjQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxJQUN4Qix1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLDZCQUFDLFVBQU8sU0FBUSxTQUFRLFNBQU8sTUFBQyxXQUFVLDBCQUN4QyxpQ0FBQyxRQUFLLElBQUcsWUFBVywyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixLQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQ0FBeUMsa0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0Msc0RBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWIsYUFBYU8sWUFBWSxHQUM3RDtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBTSxTQUFRLGtCQUFpQix1Q0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsR0FBSVIsU0FBUyxnQkFBZ0I7QUFBQTtBQUFBLGNBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdpQztBQUFBLGVBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBTSxTQUFRLGVBQWMsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFDO0FBQUEsWUFDckM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsTUFBSztBQUFBLGdCQUNMLEdBQUlBLFNBQVMsYUFBYTtBQUFBO0FBQUEsY0FINUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRzhCO0FBQUEsZUFMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLFNBQVEsR0FBSUEsU0FBUyxPQUFPLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNsQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLE9BQU0sR0FBSUEsU0FBUyxPQUFPLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsZUFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsVUFBTyxVQUFVRyxjQUFjLFdBQVUsVUFBUyxNQUFLLFVBQVMsa0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLE9BQUUsV0FBVSxrRUFBaUU7QUFBQTtBQUFBLFlBQ3JDO0FBQUEsWUFDdkMsdUJBQUMsT0FBRSxXQUFVLGdDQUErQixNQUFLLElBQUcsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUFLO0FBQUEsWUFBSTtBQUFBLFlBQ1A7QUFBQSxZQUNGLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsTUFBSyxJQUFHLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBSTtBQUFBLGVBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxXQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsU0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTREQTtBQUFBLE9BOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErREE7QUFFSjtBQUFDTCxHQWxHZUQsUUFBTTtBQUFBLFVBQ0hkLGFBTWJGLFNBRTBDeUIsV0FBVztBQUFBO0FBQUFTLEtBVDNDbEI7QUFBTSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlbG1ldCIsInVzZUZvcm0iLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ0b2FzdCIsInoiLCJyZWdpc3RlclJlc3RhdXJhbnQiLCJCdXR0b24iLCJJbnB1dCIsIkxhYmVsIiwic2lnblVwRm9ybSIsIm9iamVjdCIsInJlc3RhdXJhbnROYW1lIiwic3RyaW5nIiwibWFuYWdlck5hbWUiLCJwaG9uZSIsImVtYWlsIiwiU2lnblVwIiwiX3MiLCJuYXZpZ2F0ZSIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiZm9ybVN0YXRlIiwiaXNTdWJtaXR0aW5nIiwibXV0YXRlQXN5bmMiLCJyZWdpc3RlclJlc3RhdXJhbnRGbiIsInVzZU11dGF0aW9uIiwibXV0YXRpb25GbiIsImhhbmRsZVNpZ25VcCIsImRhdGEiLCJzdWNjZXNzIiwiYWN0aW9uIiwibGFiZWwiLCJvbkNsaWNrIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInNpZ24tdXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQtYXN5bmMnXHJcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tICdyZWFjdC1ob29rLWZvcm0nXHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXHJcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXHJcblxyXG5pbXBvcnQgeyByZWdpc3RlclJlc3RhdXJhbnQgfSBmcm9tICdAL2FwaS9yZWdpc3Rlci1yZXN0YXVyYW50J1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcclxuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvbGFiZWwnXHJcblxyXG5jb25zdCBzaWduVXBGb3JtID0gei5vYmplY3Qoe1xyXG4gIHJlc3RhdXJhbnROYW1lOiB6LnN0cmluZygpLFxyXG4gIG1hbmFnZXJOYW1lOiB6LnN0cmluZygpLFxyXG4gIHBob25lOiB6LnN0cmluZygpLFxyXG4gIGVtYWlsOiB6LnN0cmluZygpLmVtYWlsKCksXHJcbn0pXHJcblxyXG50eXBlIFNpZ25VcEZvcm0gPSB6LmluZmVyPHR5cGVvZiBzaWduVXBGb3JtPlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNpZ25VcCgpIHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICBmb3JtU3RhdGU6IHsgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08U2lnblVwRm9ybT4oKVxyXG5cclxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiByZWdpc3RlclJlc3RhdXJhbnRGbiB9ID0gdXNlTXV0YXRpb24oe1xyXG4gICAgbXV0YXRpb25GbjogcmVnaXN0ZXJSZXN0YXVyYW50LFxyXG4gIH0pXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNpZ25VcChkYXRhOiBTaWduVXBGb3JtKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCByZWdpc3RlclJlc3RhdXJhbnRGbih7XHJcbiAgICAgICAgcmVzdGF1cmFudE5hbWU6IGRhdGEucmVzdGF1cmFudE5hbWUsXHJcbiAgICAgICAgbWFuYWdlck5hbWU6IGRhdGEubWFuYWdlck5hbWUsXHJcbiAgICAgICAgZW1haWw6IGRhdGEuZW1haWwsXHJcbiAgICAgICAgcGhvbmU6IGRhdGEucGhvbmUsXHJcbiAgICAgIH0pXHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoJ1Jlc3RhdXJhbnRlIGNhZGFzdHJhZG8gY29tIHN1Y2Vzc28hJywge1xyXG4gICAgICAgIGFjdGlvbjoge1xyXG4gICAgICAgICAgbGFiZWw6ICdSZWVudmlhcicsXHJcbiAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBuYXZpZ2F0ZShgL3NpZ24taW4/ZW1haWw9JHtkYXRhLmVtYWlsfWApLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pXHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgdG9hc3QuZXJyb3IoJ0Vycm8gYW8gY2FkYXN0cmFyIHJlc3RhdXJhbnRlLicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPEhlbG1ldCB0aXRsZT1cIkNhZGFzdHJvXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGFzQ2hpbGQgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOFwiPlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvc2lnbi1pblwiPkZhemVyIGxvZ2luPC9MaW5rPlxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LVszNTBweF0gZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCBcIj5cclxuICAgICAgICAgICAgICBDcmlhciBjb250YSBncsOhdGlzXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XHJcbiAgICAgICAgICAgICAgU2VqYSB1bSBwYXJjZWlyYSBlIGNvbWVjZSBzdWFzIHZlbmRhcyFcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVTaWduVXApfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInJlc3RhdXJhbnROYW1lXCI+Tm9tZSBkbyBlc3RhYmVsZWNpbWVudG88L0xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgaWQ9XCJyZXN0YXVyYW50TmFtZVwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ3Jlc3RhdXJhbnROYW1lJyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwibWFuYWdlck5hbWVcIj5TZXUgbm9tZTwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cIm1hbmFnZXJOYW1lXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcignbWFuYWdlck5hbWUnKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPlNldSBlLW1haWw8L0xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dCBpZD1cImVtYWlsXCIgdHlwZT1cImVtYWlsXCIgey4uLnJlZ2lzdGVyKCdlbWFpbCcpfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJwaG9uZVwiPlNldSBjZWx1bGFyPC9MYWJlbD5cclxuICAgICAgICAgICAgICA8SW5wdXQgaWQ9XCJwaG9uZVwiIHR5cGU9XCJ0ZWxcIiB7Li4ucmVnaXN0ZXIoJ3Bob25lJyl9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICAgICAgRmluYWxpemFyIGNhZGFzdHJvXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHgtNiB0ZXh0LWNlbnRlciB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cclxuICAgICAgICAgICAgICBBbyBjb250aW51YXIsIHZvY8OqIGNvbmNvcmRhIGNvbSBub3Nzb3N7JyAnfVxyXG4gICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cInVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTRcIiBocmVmPVwiXCI+XHJcbiAgICAgICAgICAgICAgICB0ZXJtb3MgZGUgc2VydmnDp29cclxuICAgICAgICAgICAgICA8L2E+eycgJ31cclxuICAgICAgICAgICAgICBleycgJ31cclxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJ1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC00XCIgaHJlZj1cIlwiPlxyXG4gICAgICAgICAgICAgICAgcG9saXRpY2FzIGRlIHByaXZhY2lkYWRlXHJcbiAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgIC5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXV0aC9zaWduLXVwLnRzeCJ9