import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-revenue-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { getMonthRevenue } from "/src/api/get-month-revenue.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthRevenueCard() {
  _s();
  const { data: monthRevenue } = useQuery({
    queryFn: getMonthRevenue,
    queryKey: ["metrics", "month-revenue"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Receita total (mês)" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthRevenue ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: (monthRevenue.receipt / 100).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      }) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground", children: monthRevenue.diffFromLastMonth >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 35,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 34,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 42,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 41,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 32,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(MonthRevenueCard, "vHFdS1Bl/vEHA2FAT0QNigAEQXc=", false, function() {
  return [useQuery];
});
_c = MonthRevenueCard;
var _c;
$RefreshReg$(_c, "MonthRevenueCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/month-revenue-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBZ0JRLFVBaEJSOzJCQWpCUjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxrQkFBa0I7QUFFM0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLE1BQU1DLGFBQWFDLFlBQVlDLGlCQUFpQjtBQUV6RCxTQUFTQywwQkFBMEI7QUFFNUIsZ0JBQVNDLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsTUFBTUMsYUFBYSxJQUFJQyxTQUFTO0FBQUEsSUFDdENDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLGVBQWU7QUFBQSxFQUN2QyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxRQUNDO0FBQUEsMkJBQUMsY0FBVyxXQUFVLHdEQUNwQjtBQUFBLDZCQUFDLGFBQVUsV0FBVSwyQkFBMEIsbUNBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxXQUFVLG1DQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsU0FKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLFdBQVUsYUFDcEJILHlCQUNDLG1DQUNFO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHFDQUNaQSx3QkFBYUksVUFBVSxLQUFLQyxlQUFlLFNBQVM7QUFBQSxRQUNwREMsT0FBTztBQUFBLFFBQ1BDLFVBQVU7QUFBQSxNQUNaLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxpQ0FDVlAsdUJBQWFRLHFCQUFxQixJQUNqQyxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSwwQ0FDYlI7QUFBQUEsdUJBQWFRO0FBQUFBLFVBQWtCO0FBQUEsYUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUk7QUFBQSxXQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxJQUVBLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLG9DQUNiUjtBQUFBQSx1QkFBYVE7QUFBQUEsVUFBa0I7QUFBQSxhQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUFRO0FBQUEsUUFBSTtBQUFBLFdBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsSUFFQSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBNUJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsT0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNWLEdBL0NlRCxrQkFBZ0I7QUFBQSxVQUNDSSxRQUFRO0FBQUE7QUFBQVEsS0FEekJaO0FBQWdCLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJEb2xsYXJTaWduIiwiZ2V0TW9udGhSZXZlbnVlIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIk1ldHJpY0NhcmRTa2VsZXRvbiIsIk1vbnRoUmV2ZW51ZUNhcmQiLCJfcyIsImRhdGEiLCJtb250aFJldmVudWUiLCJ1c2VRdWVyeSIsInF1ZXJ5Rm4iLCJxdWVyeUtleSIsInJlY2VpcHQiLCJ0b0xvY2FsZVN0cmluZyIsInN0eWxlIiwiY3VycmVuY3kiLCJkaWZmRnJvbUxhc3RNb250aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsibW9udGgtcmV2ZW51ZS1jYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgRG9sbGFyU2lnbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuXHJcbmltcG9ydCB7IGdldE1vbnRoUmV2ZW51ZSB9IGZyb20gJ0AvYXBpL2dldC1tb250aC1yZXZlbnVlJ1xyXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXHJcblxyXG5pbXBvcnQgeyBNZXRyaWNDYXJkU2tlbGV0b24gfSBmcm9tICcuL21ldHJpYy1jYXJkLXNrZWxldG9uJ1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoUmV2ZW51ZUNhcmQoKSB7XHJcbiAgY29uc3QgeyBkYXRhOiBtb250aFJldmVudWUgfSA9IHVzZVF1ZXJ5KHtcclxuICAgIHF1ZXJ5Rm46IGdldE1vbnRoUmV2ZW51ZSxcclxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnbW9udGgtcmV2ZW51ZSddLFxyXG4gIH0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q2FyZD5cclxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTAgcGItMlwiPlxyXG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgIFJlY2VpdGEgdG90YWwgKG3DqnMpXHJcbiAgICAgICAgPC9DYXJkVGl0bGU+XHJcbiAgICAgICAgPERvbGxhclNpZ24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxyXG4gICAgICA8L0NhcmRIZWFkZXI+XHJcbiAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICB7bW9udGhSZXZlbnVlID8gKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgeyhtb250aFJldmVudWUucmVjZWlwdCAvIDEwMCkudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xyXG4gICAgICAgICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXHJcbiAgICAgICAgICAgICAgICBjdXJyZW5jeTogJ0JSTCcsXHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cclxuICAgICAgICAgICAgICB7bW9udGhSZXZlbnVlLmRpZmZGcm9tTGFzdE1vbnRoID49IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHttb250aFJldmVudWUuZGlmZkZyb21MYXN0TW9udGh9JVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cclxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGFvIG3DqnMgcGFzc2Fkb1xyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge21vbnRoUmV2ZW51ZS5kaWZmRnJvbUxhc3RNb250aH0lXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxyXG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBwYXNzYWRvXHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPE1ldHJpY0NhcmRTa2VsZXRvbiAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQ2FyZENvbnRlbnQ+XHJcbiAgICA8L0NhcmQ+XHJcbiAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9wYWdlcy9hcHAvZGFzaGJvYXJkL21vbnRoLXJldmVudWUtY2FyZC50c3gifQ==