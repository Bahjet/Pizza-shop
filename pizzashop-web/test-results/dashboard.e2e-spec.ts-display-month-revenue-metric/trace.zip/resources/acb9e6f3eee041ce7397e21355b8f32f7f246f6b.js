import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/popular-products-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { BarChart, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=12cb1194";
import { Cell, Pie, PieChart, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=12cb1194";
import __vite__cjsImport6_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=12cb1194"; const colors = __vite__cjsImport6_tailwindcss_colors.__esModule ? __vite__cjsImport6_tailwindcss_colors.default : __vite__cjsImport6_tailwindcss_colors;
import { getPopularProducts } from "/src/api/get-popular-products.ts?t=1713839676892";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
const COLORS = [
  colors.sky[500],
  colors.amber[500],
  colors.violet[500],
  colors.emerald[500],
  colors.rose[500]
];
export function PopularProductsChart() {
  _s();
  const { data: popularProducts } = useQuery({
    queryKey: ["metrics", "popular-products"],
    queryFn: getPopularProducts
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "col-span-3", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "pb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Produtos populares" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(BarChart, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 26,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: popularProducts ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(PieChart, { style: { fontSize: 12 }, children: /* @__PURE__ */ jsxDEV(
      Pie,
      {
        data: popularProducts,
        dataKey: "amount",
        nameKey: "product",
        cx: "50%",
        cy: "50%",
        outerRadius: 86,
        innerRadius: 64,
        strokeWidth: 8,
        labelLine: false,
        label: ({
          cx,
          cy,
          midAngle,
          innerRadius,
          outerRadius,
          value,
          index
        }) => {
          const RADIAN = Math.PI / 180;
          const radius = 12 + innerRadius + (outerRadius - innerRadius);
          const x = cx + radius * Math.cos(-midAngle * RADIAN);
          const y = cy + radius * Math.sin(-midAngle * RADIAN);
          return /* @__PURE__ */ jsxDEV(
            "text",
            {
              x,
              y,
              className: "fill-muted-foreground text-xs",
              textAnchor: x > cx ? "start" : "end",
              dominantBaseline: "central",
              children: [
                popularProducts[index].product.length > 12 ? popularProducts[index].product.substring(0, 12).concat("...") : popularProducts[index].product,
                " ",
                "(",
                value,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
              lineNumber: 62,
              columnNumber: 19
            },
            this
          );
        },
        children: popularProducts.map((_, index) => {
          return /* @__PURE__ */ jsxDEV(
            Cell,
            {
              fill: COLORS[index],
              className: "stroke-background hover:opacity-80 focus:outline-none"
            },
            `cell-${index}`,
            false,
            {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
              lineNumber: 81,
              columnNumber: 19
            },
            this
          );
        })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
        lineNumber: 37,
        columnNumber: 15
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 36,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 35,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 93,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 92,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx",
    lineNumber: 24,
    columnNumber: 5
  }, this);
}
_s(PopularProductsChart, "1VWf+RDj40U5IZM+Hb2KH8yVG/Y=", false, function() {
  return [useQuery];
});
_c = PopularProductsChart;
var _c;
$RefreshReg$(_c, "PopularProductsChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/app/dashboard/popular-products-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJVOzJCQTFCVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxVQUFVQyxlQUFlO0FBQ2xDLFNBQVNDLE1BQU1DLEtBQUtDLFVBQVVDLDJCQUEyQjtBQUN6RCxPQUFPQyxZQUFZO0FBRW5CLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsTUFBTUMsU0FBUztBQUFBLEVBQ2JOLE9BQU9PLElBQUksR0FBRztBQUFBLEVBQ2RQLE9BQU9RLE1BQU0sR0FBRztBQUFBLEVBQ2hCUixPQUFPUyxPQUFPLEdBQUc7QUFBQSxFQUNqQlQsT0FBT1UsUUFBUSxHQUFHO0FBQUEsRUFDbEJWLE9BQU9XLEtBQUssR0FBRztBQUFDO0FBR1gsZ0JBQVNDLHVCQUF1QjtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sRUFBRUMsTUFBTUMsZ0JBQWdCLElBQUlDLFNBQVM7QUFBQSxJQUN6Q0MsVUFBVSxDQUFDLFdBQVcsa0JBQWtCO0FBQUEsSUFDeENDLFNBQVNqQjtBQUFBQSxFQUNYLENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQUssV0FBVSxjQUNkO0FBQUEsMkJBQUMsY0FBVyxXQUFVLFFBQ3BCLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLGFBQVUsV0FBVSx5QkFBd0Isa0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxXQUFVLG1DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxlQUNFYyw0QkFDQyx1QkFBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFBUyxPQUFPLEVBQUVJLFVBQVUsR0FBRyxHQUM5QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUo7QUFBQUEsUUFDTixTQUFRO0FBQUEsUUFDUixTQUFRO0FBQUEsUUFDUixJQUFHO0FBQUEsUUFDSCxJQUFHO0FBQUEsUUFDSCxhQUFhO0FBQUEsUUFDYixhQUFhO0FBQUEsUUFDYixhQUFhO0FBQUEsUUFDYixXQUFXO0FBQUEsUUFDWCxPQUFPLENBQUM7QUFBQSxVQUNOSztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxRQUNGLE1BQU07QUFDSixnQkFBTUMsU0FBU0MsS0FBS0MsS0FBSztBQUN6QixnQkFBTUMsU0FBUyxLQUFLUCxlQUFlQyxjQUFjRDtBQUNqRCxnQkFBTVEsSUFBSVgsS0FBS1UsU0FBU0YsS0FBS0ksSUFBSSxDQUFDVixXQUFXSyxNQUFNO0FBQ25ELGdCQUFNTSxJQUFJWixLQUFLUyxTQUFTRixLQUFLTSxJQUFJLENBQUNaLFdBQVdLLE1BQU07QUFFbkQsaUJBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsWUFBWUksSUFBSVgsS0FBSyxVQUFVO0FBQUEsY0FDL0Isa0JBQWlCO0FBQUEsY0FFaEJMO0FBQUFBLGdDQUFnQlcsS0FBSyxFQUFFUyxRQUFRQyxTQUFTLEtBQ3JDckIsZ0JBQWdCVyxLQUFLLEVBQUVTLFFBQ3BCRSxVQUFVLEdBQUcsRUFBRSxFQUNmQyxPQUFPLEtBQUssSUFDZnZCLGdCQUFnQlcsS0FBSyxFQUFFUztBQUFBQSxnQkFBUztBQUFBLGdCQUFJO0FBQUEsZ0JBQ3RDVjtBQUFBQSxnQkFBTTtBQUFBO0FBQUE7QUFBQSxZQVpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsUUFFSjtBQUFBLFFBRUNWLDBCQUFnQndCLElBQUksQ0FBQ0MsR0FBR2QsVUFBVTtBQUNqQyxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBTXBCLE9BQU9vQixLQUFLO0FBQUEsY0FDbEIsV0FBVTtBQUFBO0FBQUEsWUFGSixRQUFPQSxLQUFNO0FBQUEsWUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdtRTtBQUFBLFFBR3ZFLENBQUM7QUFBQTtBQUFBLE1BbERIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1EQSxLQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2IsaUNBQUMsV0FBUSxXQUFVLGdEQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQTdESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0RBO0FBQUEsT0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlFQTtBQUVKO0FBQUNiLEdBbEZlRCxzQkFBb0I7QUFBQSxVQUNBSSxRQUFRO0FBQUE7QUFBQXlCLEtBRDVCN0I7QUFBb0IsSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCYXJDaGFydCIsIkxvYWRlcjIiLCJDZWxsIiwiUGllIiwiUGllQ2hhcnQiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiY29sb3JzIiwiZ2V0UG9wdWxhclByb2R1Y3RzIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIkNPTE9SUyIsInNreSIsImFtYmVyIiwidmlvbGV0IiwiZW1lcmFsZCIsInJvc2UiLCJQb3B1bGFyUHJvZHVjdHNDaGFydCIsIl9zIiwiZGF0YSIsInBvcHVsYXJQcm9kdWN0cyIsInVzZVF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZm9udFNpemUiLCJjeCIsImN5IiwibWlkQW5nbGUiLCJpbm5lclJhZGl1cyIsIm91dGVyUmFkaXVzIiwidmFsdWUiLCJpbmRleCIsIlJBRElBTiIsIk1hdGgiLCJQSSIsInJhZGl1cyIsIngiLCJjb3MiLCJ5Iiwic2luIiwicHJvZHVjdCIsImxlbmd0aCIsInN1YnN0cmluZyIsImNvbmNhdCIsIm1hcCIsIl8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInBvcHVsYXItcHJvZHVjdHMtY2hhcnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBCYXJDaGFydCwgTG9hZGVyMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgQ2VsbCwgUGllLCBQaWVDaGFydCwgUmVzcG9uc2l2ZUNvbnRhaW5lciB9IGZyb20gJ3JlY2hhcnRzJ1xyXG5pbXBvcnQgY29sb3JzIGZyb20gJ3RhaWx3aW5kY3NzL2NvbG9ycydcclxuXHJcbmltcG9ydCB7IGdldFBvcHVsYXJQcm9kdWN0cyB9IGZyb20gJ0AvYXBpL2dldC1wb3B1bGFyLXByb2R1Y3RzJ1xyXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXHJcblxyXG5jb25zdCBDT0xPUlMgPSBbXHJcbiAgY29sb3JzLnNreVs1MDBdLFxyXG4gIGNvbG9ycy5hbWJlcls1MDBdLFxyXG4gIGNvbG9ycy52aW9sZXRbNTAwXSxcclxuICBjb2xvcnMuZW1lcmFsZFs1MDBdLFxyXG4gIGNvbG9ycy5yb3NlWzUwMF0sXHJcbl1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBQb3B1bGFyUHJvZHVjdHNDaGFydCgpIHtcclxuICBjb25zdCB7IGRhdGE6IHBvcHVsYXJQcm9kdWN0cyB9ID0gdXNlUXVlcnkoe1xyXG4gICAgcXVlcnlLZXk6IFsnbWV0cmljcycsICdwb3B1bGFyLXByb2R1Y3RzJ10sXHJcbiAgICBxdWVyeUZuOiBnZXRQb3B1bGFyUHJvZHVjdHMsXHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImNvbC1zcGFuLTNcIj5cclxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwicGItOFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICBQcm9kdXRvcyBwb3B1bGFyZXNcclxuICAgICAgICAgIDwvQ2FyZFRpdGxlPlxyXG4gICAgICAgICAgPEJhckNoYXJ0IGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9DYXJkSGVhZGVyPlxyXG4gICAgICA8Q2FyZENvbnRlbnQ+XHJcbiAgICAgICAge3BvcHVsYXJQcm9kdWN0cyA/IChcclxuICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjQwfT5cclxuICAgICAgICAgICAgPFBpZUNoYXJ0IHN0eWxlPXt7IGZvbnRTaXplOiAxMiB9fT5cclxuICAgICAgICAgICAgICA8UGllXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtwb3B1bGFyUHJvZHVjdHN9XHJcbiAgICAgICAgICAgICAgICBkYXRhS2V5PVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgIG5hbWVLZXk9XCJwcm9kdWN0XCJcclxuICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs4Nn1cclxuICAgICAgICAgICAgICAgIGlubmVyUmFkaXVzPXs2NH1cclxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXs4fVxyXG4gICAgICAgICAgICAgICAgbGFiZWxMaW5lPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGxhYmVsPXsoe1xyXG4gICAgICAgICAgICAgICAgICBjeCxcclxuICAgICAgICAgICAgICAgICAgY3ksXHJcbiAgICAgICAgICAgICAgICAgIG1pZEFuZ2xlLFxyXG4gICAgICAgICAgICAgICAgICBpbm5lclJhZGl1cyxcclxuICAgICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXMsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICBpbmRleCxcclxuICAgICAgICAgICAgICAgIH0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgUkFESUFOID0gTWF0aC5QSSAvIDE4MFxyXG4gICAgICAgICAgICAgICAgICBjb25zdCByYWRpdXMgPSAxMiArIGlubmVyUmFkaXVzICsgKG91dGVyUmFkaXVzIC0gaW5uZXJSYWRpdXMpXHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHggPSBjeCArIHJhZGl1cyAqIE1hdGguY29zKC1taWRBbmdsZSAqIFJBRElBTilcclxuICAgICAgICAgICAgICAgICAgY29uc3QgeSA9IGN5ICsgcmFkaXVzICogTWF0aC5zaW4oLW1pZEFuZ2xlICogUkFESUFOKVxyXG5cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8dGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgeD17eH1cclxuICAgICAgICAgICAgICAgICAgICAgIHk9e3l9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaWxsLW11dGVkLWZvcmVncm91bmQgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0QW5jaG9yPXt4ID4gY3ggPyAnc3RhcnQnIDogJ2VuZCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkb21pbmFudEJhc2VsaW5lPVwiY2VudHJhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BvcHVsYXJQcm9kdWN0c1tpbmRleF0ucHJvZHVjdC5sZW5ndGggPiAxMlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHBvcHVsYXJQcm9kdWN0c1tpbmRleF0ucHJvZHVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN1YnN0cmluZygwLCAxMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jb25jYXQoJy4uLicpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogcG9wdWxhclByb2R1Y3RzW2luZGV4XS5wcm9kdWN0fXsnICd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAoe3ZhbHVlfSlcclxuICAgICAgICAgICAgICAgICAgICA8L3RleHQ+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3BvcHVsYXJQcm9kdWN0cy5tYXAoKF8sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENlbGxcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17YGNlbGwtJHtpbmRleH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD17Q09MT1JTW2luZGV4XX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0cm9rZS1iYWNrZ3JvdW5kIGhvdmVyOm9wYWNpdHktODAgZm9jdXM6b3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtWzI0MHB4XSB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtOCB3LTggYW5pbWF0ZS1zcGluIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgPC9DYXJkPlxyXG4gIClcclxufVxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FjZXIgTml0cm8gNS9EZXNrdG9wL3JvY2tldHNlYXQvaWduaXRlL3JlYWN0L3JlYWN0LTQvcGl6emFzaG9wLXdlYi9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9wb3B1bGFyLXByb2R1Y3RzLWNoYXJ0LnRzeCJ9