import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-in.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=12cb1194"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=12cb1194";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=12cb1194";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=12cb1194";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=12cb1194";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=12cb1194";
import { z } from "/node_modules/.vite/deps/zod.js?v=12cb1194";
import { signIn } from "/src/api/sign-in.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signInForm = z.object({
  email: z.string().email()
});
export function SignIn() {
  _s();
  const [searchParams] = useSearchParams();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    defaultValues: {
      email: searchParams.get("email") ?? ""
    }
  });
  const { mutateAsync: authenticate } = useMutation({
    mutationFn: signIn
  });
  async function handleSignIn(data) {
    try {
      await authenticate({ email: data.email });
      toast.success("Enviamos um link de autenticação para seu e-mail.", {
        action: {
          label: "Reenviar",
          onClick: () => handleSignIn(data)
        }
      });
    } catch {
      toast.error("Credenciais Inválidas.");
    }
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Login" }, void 0, false, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", asChild: true, className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-up", children: "Novo estabelecimento" }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
        lineNumber: 56,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight ", children: "Acessar painel" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
            lineNumber: 60,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Acompanhe suas vendas pelo painel do parceiro!" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleSubmit(handleSignIn), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
              lineNumber: 70,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                disabled: isSubmitting,
                id: "email",
                type: "email",
                ...register("email")
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
                lineNumber: 71,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
            lineNumber: 69,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, className: "w-full", type: "submit", children: "Acessar painel" }, void 0, false, {
            fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
            lineNumber: 79,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
          lineNumber: 68,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(SignIn, "ikPhmheRD3mlcGeo28rH4K0wdFw=", false, function() {
  return [useSearchParams, useForm, useMutation];
});
_c = SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Acer Nitro 5/Desktop/rocketseat/ignite/react/react-4/pizzashop-web/src/pages/auth/sign-in.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURJLG1CQUNFLGNBREY7MkJBbkRKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLGFBQWFMLEVBQUVNLE9BQU87QUFBQSxFQUMxQkMsT0FBT1AsRUFBRVEsT0FBTyxFQUFFRCxNQUFNO0FBQzFCLENBQUM7QUFJTSxnQkFBU0UsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsWUFBWSxJQUFJYixnQkFBZ0I7QUFFdkMsUUFBTTtBQUFBLElBQ0pjO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUluQixRQUFvQjtBQUFBLElBQ3RCb0IsZUFBZTtBQUFBLE1BQ2JULE9BQU9JLGFBQWFNLElBQUksT0FBTyxLQUFLO0FBQUEsSUFDdEM7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNLEVBQUVDLGFBQWFDLGFBQWEsSUFBSUMsWUFBWTtBQUFBLElBQ2hEQyxZQUFZcEI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsaUJBQWVxQixhQUFhQyxNQUFrQjtBQUM1QyxRQUFJO0FBQ0YsWUFBTUosYUFBYSxFQUFFWixPQUFPZ0IsS0FBS2hCLE1BQU0sQ0FBQztBQUV4Q1IsWUFBTXlCLFFBQVEscURBQXFEO0FBQUEsUUFDakVDLFFBQVE7QUFBQSxVQUNOQyxPQUFPO0FBQUEsVUFDUEMsU0FBU0EsTUFBTUwsYUFBYUMsSUFBSTtBQUFBLFFBQ2xDO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxRQUFRO0FBQ054QixZQUFNNkIsTUFBTSx3QkFBd0I7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFRLFNBQVEsU0FBTyxNQUFDLFdBQVUsMEJBQ3hDLGlDQUFDLFFBQUssSUFBRyxZQUFXLG9DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBDQUF5Qyw4QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUFnQyw4REFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVZixhQUFhUyxZQUFZLEdBQzdEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFVBQVVQO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsR0FBSUgsU0FBUyxPQUFPO0FBQUE7QUFBQSxjQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJd0I7QUFBQSxlQU4xQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxVQUFPLFVBQVVHLGNBQWMsV0FBVSxVQUFTLE1BQUssVUFBUyw4QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLFNBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ0wsR0FwRWVELFFBQU07QUFBQSxVQUNHWCxpQkFNbkJGLFNBTWtDd0IsV0FBVztBQUFBO0FBQUFTLEtBYm5DcEI7QUFBTSxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlbG1ldCIsInVzZUZvcm0iLCJMaW5rIiwidXNlU2VhcmNoUGFyYW1zIiwidG9hc3QiLCJ6Iiwic2lnbkluIiwiQnV0dG9uIiwiSW5wdXQiLCJMYWJlbCIsInNpZ25JbkZvcm0iLCJvYmplY3QiLCJlbWFpbCIsInN0cmluZyIsIlNpZ25JbiIsIl9zIiwic2VhcmNoUGFyYW1zIiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJpc1N1Ym1pdHRpbmciLCJkZWZhdWx0VmFsdWVzIiwiZ2V0IiwibXV0YXRlQXN5bmMiLCJhdXRoZW50aWNhdGUiLCJ1c2VNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJoYW5kbGVTaWduSW4iLCJkYXRhIiwic3VjY2VzcyIsImFjdGlvbiIsImxhYmVsIiwib25DbGljayIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJzaWduLWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJ1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcidcclxuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcclxuXHJcbmltcG9ydCB7IHNpZ25JbiB9IGZyb20gJ0AvYXBpL3NpZ24taW4nXHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXHJcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2lucHV0J1xyXG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9sYWJlbCdcclxuXHJcbmNvbnN0IHNpZ25JbkZvcm0gPSB6Lm9iamVjdCh7XHJcbiAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoKSxcclxufSlcclxuXHJcbnR5cGUgU2lnbkluRm9ybSA9IHouaW5mZXI8dHlwZW9mIHNpZ25JbkZvcm0+XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2lnbkluKCkge1xyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICBmb3JtU3RhdGU6IHsgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08U2lnbkluRm9ybT4oe1xyXG4gICAgZGVmYXVsdFZhbHVlczoge1xyXG4gICAgICBlbWFpbDogc2VhcmNoUGFyYW1zLmdldCgnZW1haWwnKSA/PyAnJyxcclxuICAgIH0sXHJcbiAgfSlcclxuXHJcbiAgY29uc3QgeyBtdXRhdGVBc3luYzogYXV0aGVudGljYXRlIH0gPSB1c2VNdXRhdGlvbih7XHJcbiAgICBtdXRhdGlvbkZuOiBzaWduSW4sXHJcbiAgfSlcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU2lnbkluKGRhdGE6IFNpZ25JbkZvcm0pIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGF1dGhlbnRpY2F0ZSh7IGVtYWlsOiBkYXRhLmVtYWlsIH0pXHJcblxyXG4gICAgICB0b2FzdC5zdWNjZXNzKCdFbnZpYW1vcyB1bSBsaW5rIGRlIGF1dGVudGljYcOnw6NvIHBhcmEgc2V1IGUtbWFpbC4nLCB7XHJcbiAgICAgICAgYWN0aW9uOiB7XHJcbiAgICAgICAgICBsYWJlbDogJ1JlZW52aWFyJyxcclxuICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGhhbmRsZVNpZ25JbihkYXRhKSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRvYXN0LmVycm9yKCdDcmVkZW5jaWFpcyBJbnbDoWxpZGFzLicpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPEhlbG1ldCB0aXRsZT1cIkxvZ2luXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJnaG9zdFwiIGFzQ2hpbGQgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOFwiPlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvc2lnbi11cFwiPk5vdm8gZXN0YWJlbGVjaW1lbnRvPC9MaW5rPlxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LVszNTBweF0gZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0cmFja2luZy10aWdodCBcIj5cclxuICAgICAgICAgICAgICBBY2Vzc2FyIHBhaW5lbFxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxyXG4gICAgICAgICAgICAgIEFjb21wYW5oZSBzdWFzIHZlbmRhcyBwZWxvIHBhaW5lbCBkbyBwYXJjZWlybyFcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVTaWduSW4pfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+U2V1IGUtbWFpbDwvTGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKCdlbWFpbCcpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiB0eXBlPVwic3VibWl0XCI+XHJcbiAgICAgICAgICAgICAgQWNlc3NhciBwYWluZWxcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKVxyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQWNlciBOaXRybyA1L0Rlc2t0b3Avcm9ja2V0c2VhdC9pZ25pdGUvcmVhY3QvcmVhY3QtNC9waXp6YXNob3Atd2ViL3NyYy9wYWdlcy9hdXRoL3NpZ24taW4udHN4In0=